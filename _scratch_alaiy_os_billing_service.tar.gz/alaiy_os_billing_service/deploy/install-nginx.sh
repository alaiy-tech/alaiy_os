#!/usr/bin/env bash
# Install the edge proxies on the instance (Amazon Linux 2023).
#
#   sudo ./deploy/install-nginx.sh billing.example.com [gateway.example.com]
#
# The gateway host is optional. Omit it and only the billing proxy is
# installed, which is the behaviour this script had originally.
#
# Idempotent: safe to re-run after editing deploy/nginx/*.conf. Does NOT issue
# certificates — those need the A records to resolve first, and the commands
# are printed at the end.
set -euo pipefail

HOST="${1:-}"
GATEWAY_HOST="${2:-}"
if [[ -z "$HOST" ]]; then
    echo "usage: $0 <billing-hostname> [gateway-hostname]" >&2
    echo "   e.g. $0 billing.example.com gateway.example.com" >&2
    exit 64
fi

if [[ -n "$GATEWAY_HOST" && "$GATEWAY_HOST" == "$HOST" ]]; then
    echo "billing and gateway hostnames must differ (both '$HOST')" >&2
    exit 64
fi

if [[ $EUID -ne 0 ]]; then
    echo "must run as root (sudo $0 $HOST)" >&2
    exit 77
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

dnf install -y nginx certbot python3-certbot-nginx

# Webroot for the ACME http-01 challenge; must match `root` in billing.conf.
mkdir -p /var/www/certbot

install -m 644 "$HERE/nginx/billing-proxy-params" /etc/nginx/conf.d/billing-proxy-params
# Render a template into conf.d, but NEVER clobber a live file that certbot has
# already taken ownership of.
#
# The templates in this repo are HTTP-only on purpose: certbot appends the TLS
# server block and the 80 -> 443 redirect directly to the installed file, and
# that block exists nowhere else. A plain `sed > dest` on a re-run therefore
# silently deletes the only copy of the TLS config and takes HTTPS down until
# the certificate is re-issued. Refuse instead, and say what to do.
render_conf() {
    local src="$1" dest="$2" placeholder="$3" value="$4"

    if [[ -f "$dest" ]] && grep -q "managed by Certbot\|listen 443" "$dest"; then
        echo "skip: $dest is certbot-managed; leaving it alone." >&2
        echo "      To pick up template changes, edit $dest by hand, or delete" >&2
        echo "      it and re-run, then re-issue with: certbot --nginx -d $value" >&2
        return 0
    fi

    sed "s/$placeholder/$value/g" "$src" > "$dest"
    echo "wrote: $dest"
}

render_conf "$HERE/nginx/billing.conf" /etc/nginx/conf.d/billing.conf \
    __BILLING_HOST__ "$HOST"

# nginx loads conf.d/*.conf alphabetically and treats the first server on :80
# as the default for unmatched Host headers. billing.conf sorts before
# gateway.conf, so billing stays the default — keep it that way if either file
# is ever renamed.
if [[ -n "$GATEWAY_HOST" ]]; then
    install -m 644 "$HERE/nginx/gateway-proxy-params" /etc/nginx/conf.d/gateway-proxy-params
    render_conf "$HERE/nginx/gateway.conf" /etc/nginx/conf.d/gateway.conf \
        __GATEWAY_HOST__ "$GATEWAY_HOST"
fi

# Amazon Linux ships a default server on :80 that would otherwise answer for
# any Host we do not match. Drop it if it is still the stock file.
if [[ -f /etc/nginx/conf.d/default.conf ]]; then
    mv /etc/nginx/conf.d/default.conf /etc/nginx/conf.d/default.conf.disabled
fi

nginx -t
systemctl enable --now nginx
systemctl reload nginx

# Renewal timer ships with the certbot package; enabling it now means the first
# issuance is the only manual step.
systemctl enable --now certbot-renew.timer 2>/dev/null \
    || echo "note: certbot-renew.timer not found; check 'systemctl list-timers | grep certbot'"

cat <<EOF

nginx is up and proxying http://$HOST/ -> 127.0.0.1:8080

Verify now, before DNS resolves:
    curl -s -H 'Host: $HOST' http://127.0.0.1/health

Once the A record for $HOST resolves to this instance and port 80 is open in
the security group, issue the certificate:
    sudo certbot --nginx -d $HOST

Then confirm renewal is wired up:
    sudo certbot renew --dry-run
EOF

if [[ -n "$GATEWAY_HOST" ]]; then
cat <<EOF

gateway is proxying http://$GATEWAY_HOST/v1/ -> 127.0.0.1:4000
Only /v1/* and /health/liveliness are routed; every other path returns 404,
which keeps LiteLLM's admin API (/key/*, /spend/*, /ui) off the internet.
Reach those over an SSH tunnel instead:
    ssh -L 4000:127.0.0.1:4000 ec2-user@<instance>

Verify now, before DNS resolves:
    curl -s -H 'Host: $GATEWAY_HOST' http://127.0.0.1/health/liveliness
    curl -s -o /dev/null -w '%{http_code}\\n' -H 'Host: $GATEWAY_HOST' \\
        http://127.0.0.1/key/info          # must print 404

Add an A record for $GATEWAY_HOST -> this instance, then:
    sudo certbot --nginx -d $GATEWAY_HOST

Point clients at:
    base_url = https://$GATEWAY_HOST/v1
EOF
fi
