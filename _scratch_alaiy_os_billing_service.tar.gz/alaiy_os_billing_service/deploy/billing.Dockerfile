# Billing control plane. Build context is the repo root (see docker-compose.yml).
FROM python:3.13-slim

WORKDIR /srv

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app ./app

# BILLING_DB_PATH points here; the compose file mounts a named volume so the
# ledger outlives container rebuilds.
RUN mkdir -p /data

EXPOSE 8080
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8080"]
