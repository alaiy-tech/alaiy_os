# Alaiy OS Platform — Gateway + Billing

Two services, one repo, one `docker compose up`:

| Service | What it is | Port |
|---|---|---|
| **gateway** | LiteLLM proxy — the data plane benches send inference to | 4000 |
| **billing** | Control plane — sole holder of the LiteLLM master key and all Razorpay credentials | 8080 |
| db | Postgres — LiteLLM's keys, spend and budgets | internal |

Benches never touch LiteLLM's admin API. They call billing, which mints and
returns their scoped virtual key. Money logic (markup, ledger, budget sync,
payment verification) lives only in billing.

LiteLLM is consumed as a **pinned upstream image**, never built from source. Our
only customisation is `gateway/config.yaml`, mounted in at runtime.

## Run

```bash
cp .env.example .env      # fill in the two secrets below
docker compose -f deploy/docker-compose.yml up -d
```

Cold start (including a fresh Postgres) is about 10 seconds. That is the whole
setup — there is no separate LiteLLM repo to clone, configure or launch.

Only two values in `.env` actually need filling:

```bash
OPENROUTER_API_KEY=       # openrouter.ai/keys; one key covers every model here
LITELLM_MASTER_KEY=       # generate: python3 -c 'import secrets; print("sk-alaiy-"+secrets.token_urlsafe(32))'
```

Everything else has a working dev default. Do **not** leave the master key as
`sk-1234` — that is LiteLLM's documented default and the first thing an attacker
tries against port 4000.

Verify:

```bash
curl localhost:4000/health/liveliness              # gateway
curl localhost:8080/health                         # billing
curl -H "Authorization: Bearer $LITELLM_MASTER_KEY" localhost:4000/v1/models
```

## The billing invariant

**A call that consumes tokens must never record $0 of spend.** Everything about
the model catalogue follows from this, so it is worth understanding before
changing `gateway/config.yaml`.

LiteLLM prices calls two different ways:

- **Non-streaming** — it sends `usage: {include: true}` and uses the cost the
  provider reports back. Accurate with no configuration at all.
- **Streaming** — that provider-reported cost is *never read*. Cost comes only
  from a price LiteLLM already knows.

So a streamed call to a model with no known price records `spend = 0.0`. Benches
stream, and LiteLLM's bundled cost map lags provider releases by weeks.
Measured, same model and same request:

| Config | Streamed spend |
|---|---|
| Wildcard entry, no price | **`0.0`** |
| Explicit price | `3.45e-05` (correct) |

Hence: **every catalogue entry carries an explicit price, so "unpriced" means
"unreachable" rather than "free".** Never add a wildcard entry to
`gateway/config.yaml` — it reopens exactly this hole.

Because everything reachable is priced, `ALLOWED_MODELS` can safely be left
blank (see below).

## Model catalogue

`gateway/config.yaml` is **generated** — do not hand-edit it.

```bash
python3 gateway/build_config.py           # regenerate
python3 gateway/build_config.py --check   # exit 1 if any model has repriced
```

It enumerates **every priced text model on OpenRouter** (305 of them, ~610
aliases), all routed through OpenRouter on `OPENROUTER_API_KEY`. OpenAI,
Anthropic, Google, Meta, Mistral, Qwen and DeepSeek are all reachable on that one
credential. Only two exclusions remain, both about billing correctness:

- image/audio output — charged per image or audio second, which a per-token
  price cannot express. Image work is served off-gateway by `/image/*` instead.
- anything with a zero or missing price — this is what catches `:free` variants,
  and including one would reintroduce the $0 hole.

Everything the Gemini-direct version had to exclude by hand (`-fast`,
`-customtools`, non-Gemini `google/*`) is now included: those are OpenRouter ids
with OpenRouter prices, and OpenRouter is the biller, so they price correctly on
their own terms.

**Aliases.** Each model answers to two names: its full OpenRouter id
(`anthropic/claude-sonnet-5`) and its bare name (`claude-sonnet-5`). The bare
alias is emitted only where it is unambiguous across the catalogue — if two
providers ever ship the same name, only the full id is offered, so an alias can
never silently resolve to the wrong backend. The bare form is also what keeps
pre-existing agents working across the switch from Gemini-direct, where
`gemini-3.1-flash-lite` was the only spelling.

**Where the prices come from.** `build_config.py` reads OpenRouter's public
catalogue endpoint (no key needed), which is also what OpenRouter charges us.
Catalogue, prices and routing are therefore one system, and the recorded price is
exact.

That is a real improvement over the Gemini-direct arrangement this replaced,
which read prices from OpenRouter but routed to Google. It inherited a seam —
OpenRouter quotes one price per model, while Google bills Pro models higher above
a 200k-token context — so long-context spend was silently **under**-recorded.
Routing and pricing now come from the same place, so that gap is closed.

After regenerating:

```bash
docker compose -f deploy/docker-compose.yml up -d --force-recreate litellm
```

`--force-recreate`, not `restart`: a plain restart reuses the existing container
and will not pick up `.env` or config changes.

## Operations

Both failures this guards against are silent — a `$0` row looks exactly like a
cheap request. Wire these into CI or a cron:

```bash
python3 gateway/build_config.py --check      # catalogue prices drifted
python3 gateway/audit_zero_cost.py           # any call with tokens but spend=0
python3 gateway/audit_zero_cost.py --hours 168 --exit-code
```

**Pinning.** `deploy/docker-compose.yml` pins `litellm:v1.93.0` deliberately.
`main-stable` is a moving tag: a later `pull` can change the `/key/generate` or
`/key/info` response shape, which surfaces as a billing bug rather than a gateway
error. Bump on purpose, then re-run the checks above.

**If you ever need to patch LiteLLM's source**, build the
`alaiy-tech/alaiy_os_lite_llm` fork, push to `ghcr.io/alaiy-tech/litellm:<sha>`,
and change the one `image:` line. Nothing else here needs to know.

**Spend is written asynchronously** — it can take 10–30s to land after a call.
`/balance` reads LiteLLM directly, so a bench polling immediately after a
request may briefly see a stale number.

**Streaming accuracy.** Without `stream_options: {include_usage: true}` LiteLLM
estimates token counts (measured ~8% off). Still non-zero, so the invariant
holds, but bench clients should send that flag for exact billing.

## Endpoints

Billing (`:8080`):

| Endpoint | Auth | Purpose |
|---|---|---|
| `GET /health` | — | `{ok, razorpay}` |
| `POST /provision` | bootstrap token | `{gateway_url, key, bench_token, models, reused}` — idempotent per site |
| `POST /topup/order` | bench token | Create a Razorpay order (or a mock one). `{amount}` in USD — USD is the only currency accepted |
| `POST /topup/verify` | bench token | Credit from a Checkout callback (signature-verified) |
| `POST /topup/confirm` | bench token | Mock-only credit path; disabled when Razorpay is configured |
| `POST /razorpay/webhook` | Razorpay signature | Production credit path |
| `GET /balance` | bench token | `{site, balance_usd}` |
| `POST /image/generate` | bench token | `{b64, media_type, usage}` — one generated image |
| `POST /image/translate` | bench token | `{translated_url}` — one photo's printed text into English |

`/provision` body: `{"site": "core.os.alaiy.com"}`. It never mints a duplicate
key for a site, and returns a fresh per-bench token each call.

### Why the image endpoints exist here

The load-bearing reason is **translation**. alphashop is not an LLM API at all —
no model id, its own JWT auth, its own response contract — so LiteLLM cannot
front it whatever providers the catalogue carries. An image endpoint on this
service is therefore required regardless of how the gateway is configured.

Given that, **generation sits beside it** so both share one credential holder and
one metering path. The alternative — translation metered by hand here, generation
metered by LiteLLM — puts two mechanisms behind one balance, which is exactly the
kind of split that produces a wrong ledger.

A secondary and *changeable* fact: the catalogue currently carries no image model,
because `build_config.py` reads per-token prices from OpenRouter's `/models` and
drops non-text output modalities. That is a property of the generator, not a limit
of LiteLLM — LiteLLM can price images (`input_cost_per_image`,
`input_cost_per_image_token`), and it has an OpenRouter image-generation path
(routed via `/chat/completions`, not the Unified Image API this service uses).

So if the gateway later fronts image models, generation *could* move onto it. That
would be a deliberate trade — LiteLLM's own accounting in exchange for two metering
paths — and nothing on a bench would change, since benches only ever see the
`ai_client` seam.

Both calls are made from here, in `providers.py`, on our keys — the same principle
as the master key. A bench asks for the work and gets the result; it never holds a
provider credential.

They are metered by hand, since LiteLLM cannot meter what it never sees. Each
successful call appends a row to the `usage` table and lowers the site's LiteLLM
budget ceiling by the same amount, so image and text spend draw down one balance
and `/balance` needs no special case. The ceiling is always recomputed from the
append-only tables rather than adjusted by a delta — that is what makes it safe
for concurrent image calls, and what stops a top-up from silently refunding image
spend. Failed calls are not billed, and a site out of credit gets a 402 before the
provider is touched.

Per-image prices are explicit (`IMAGE_GENERATE_COST_USD`, `IMAGE_TRANSLATE_COST_USD`)
for the same reason every model carries an explicit price: neither provider reports
a usable cost back, so a 0 here means billable upstream but free to the customer.

## Security model

- The **master key** lives only in billing, used only in `litellm_client.py`.
  Benches receive a scoped virtual key, never the master key.
- Benches authenticate to `/provision` with `BILLING_BOOTSTRAP_TOKEN`, which
  authorizes only "provision my own bench" — never key management or
  cross-tenant reads. They then use a per-bench token for money endpoints.
- `MARKUP` (vendor margin) lives only here; a bench never sees it. Real budget
  granted = `amount_paid / MARKUP`.
- Razorpay credentials live only here. `/topup/confirm` is disabled whenever
  real Razorpay keys are set, so production cannot credit without a verified
  payment.
- **Image provider keys** (`OPENROUTER_API_KEY`, `ALPHASHOP_AK`/`SK`) live only
  here, used only in `providers.py`. They used to sit in each bench's
  `site_config.json`, which put them on customer-controlled filesystems and left
  image spend outside budgeting entirely.
- `ALLOWED_MODELS` is a **global** narrowing, applied to every key — there is no
  per-site override. Blank (the default) means every model in the catalogue,
  which is safe because every catalogue entry is priced. Set it only to withhold
  models a bench could otherwise reach; it buys no billing safety.

## Layout

```
app/                     billing service (FastAPI)
  main.py                endpoints
  litellm_client.py      the ONLY place the master key is used
  providers.py           the ONLY place the image provider keys are used
  db.py                  SQLite: bench, orders, ledger, usage, bench_token
  config.py, razorpay_client.py
gateway/
  build_config.py        catalogue generator + --check drift detector
  config.yaml            GENERATED — do not hand-edit
  audit_zero_cost.py     finds calls that billed $0 despite using tokens
deploy/
  docker-compose.yml     gateway + billing + postgres
  billing.Dockerfile
```
