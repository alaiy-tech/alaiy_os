#!/usr/bin/env python3
"""Audit LiteLLM's spend logs for calls that consumed tokens but billed $0.

This is the backstop for the invariant that gateway/build_config.py enforces
structurally. That script guarantees every reachable model has a price; this one
verifies the guarantee actually held in production, because the failure mode is
silent — a $0 row looks exactly like a cheap request, and nothing errors.

    python3 gateway/audit_zero_cost.py                  # last 24h
    python3 gateway/audit_zero_cost.py --hours 168      # last week
    python3 gateway/audit_zero_cost.py --exit-code      # exit 1 if any found

Reads Postgres directly rather than /spend/logs: the table is the ledger's own
source of truth, and this must not depend on the proxy being healthy.

Note a legitimately-free row is possible (a free-tier Gemini call, or a request
that errored after tokens were counted). Every catalogue entry is priced, so
under the intended setup a hit here is a real billing leak.
"""

import argparse
import subprocess
import sys
from pathlib import Path

# Resolved from this file, not the cwd, so cron and CI can invoke it by absolute
# path without a `cd` first.
COMPOSE = Path(__file__).resolve().parent.parent / "deploy" / "docker-compose.yml"

QUERY = """
SELECT
  model,
  count(*)                                  AS calls,
  sum(prompt_tokens + completion_tokens)    AS tokens,
  max("startTime")                          AS latest
FROM "LiteLLM_SpendLogs"
WHERE "startTime" > now() - interval '{hours} hours'
  AND coalesce(spend, 0) = 0
  AND coalesce(prompt_tokens, 0) + coalesce(completion_tokens, 0) > 0
GROUP BY model
ORDER BY tokens DESC;
"""


def run(hours: int) -> str:
    """Query the spend log through the compose db container.

    Uses `compose exec` rather than a local psql client so it needs no host
    Postgres tooling and no credentials in this file.
    """
    cmd = [
        "docker", "compose", "-f", str(COMPOSE),
        "exec", "-T", "db", "psql", "-U", "llmproxy", "-d", "litellm",
        "-A", "-F", "\t", "-t", "-c", QUERY.format(hours=hours),
    ]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        sys.exit(f"could not query spend logs: {e}")
    if p.returncode != 0:
        sys.exit(f"could not query spend logs: {p.stderr.strip()}")
    return p.stdout


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hours", type=int, default=24)
    ap.add_argument("--exit-code", action="store_true", help="exit 1 if leaks found")
    args = ap.parse_args()

    rows = [r for r in run(args.hours).strip().splitlines() if r.strip()]
    if not rows:
        print(f"OK: no zero-cost billable calls in the last {args.hours}h.")
        return

    print(f"LEAK: {len(rows)} model(s) billed $0 despite consuming tokens "
          f"(last {args.hours}h)\n")
    print(f"  {'model':45} {'calls':>7} {'tokens':>9}  latest")
    total = 0
    for r in rows:
        parts = [c.strip() for c in r.split("\t")]
        if len(parts) < 4:
            continue
        model, calls, tokens, latest = parts[0], parts[1], parts[2], parts[3]
        total += int(tokens or 0)
        print(f"  {model:45} {calls:>7} {tokens:>9}  {latest[:19]}")
    print(f"\n  {total} tokens served free.")
    print("  Fix: python3 gateway/build_config.py  (re-price the catalogue), then")
    print("       docker compose -f deploy/docker-compose.yml up -d --force-recreate litellm")
    if args.exit_code:
        sys.exit(1)


if __name__ == "__main__":
    main()
