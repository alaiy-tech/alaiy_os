"""Razorpay integration — order creation + signature verification.

Only the billing service ever touches Razorpay credentials. If key/secret are
unset, `enabled()` is False and the caller falls back to mock behaviour so
local dev works without Razorpay access.
"""

from app.config import (
    RAZORPAY_KEY_ID,
    RAZORPAY_KEY_SECRET,
    RAZORPAY_WEBHOOK_SECRET,
)


def enabled() -> bool:
    return bool(RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET)


def _client():
    import razorpay

    return razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))


def create_order(amount: float, notes: dict) -> dict:
    """Create a USD Razorpay order. Amount is sent in cents, USD being a
    2-decimal currency. USD is the only currency this service bills in."""
    return _client().order.create(
        {
            "amount": int(round(amount * 100)),
            "currency": "USD",
            "notes": notes,
            "payment_capture": 1,
        }
    )


def verify_payment_signature(params: dict) -> bool:
    """Verify a Checkout success callback (order_id + payment_id + signature).

    Lets us confirm a real payment from the browser callback without needing a
    public webhook — handy for local test-mode testing.
    """
    import razorpay

    try:
        _client().utility.verify_payment_signature(params)
        return True
    except razorpay.errors.SignatureVerificationError:
        return False


def verify_webhook_signature(body: bytes, signature: str) -> bool:
    """Verify a server-to-server webhook (production credit path)."""
    import razorpay

    try:
        _client().utility.verify_webhook_signature(
            body.decode(), signature or "", RAZORPAY_WEBHOOK_SECRET
        )
        return True
    except razorpay.errors.SignatureVerificationError:
        return False
