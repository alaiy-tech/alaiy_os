"""Thin client for LiteLLM's admin (control-plane) API.

Uses the master key. This module is the only place the master key is used.
"""

import httpx

from app.config import ALLOWED_MODELS, LITELLM_BASE_URL, LITELLM_MASTER_KEY

_HEADERS = {"Authorization": f"Bearer {LITELLM_MASTER_KEY}"}


def create_virtual_key(site: str, budget: float) -> str:
    """Create a per-site virtual key scoped to ALLOWED_MODELS + a budget.

    The model scope is global (one list for every bench) and is enforced by the
    gateway, so it holds even though the bench holds the key.

    An empty ALLOWED_MODELS sends `models: []`, which LiteLLM reads as "every
    model in the catalogue". That is safe here because every catalogue entry
    carries an explicit price — see gateway/build_config.py. It would NOT be safe
    against a wildcard entry, which would make unpriced models reachable and
    therefore streamable at $0.
    """
    resp = httpx.post(
        f"{LITELLM_BASE_URL}/key/generate",
        headers=_HEADERS,
        json={
            "key_alias": site,
            "max_budget": budget,
            "models": ALLOWED_MODELS,
            "metadata": {"site": site},
        },
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json()["key"]


def set_budget(vk: str, max_budget: float) -> None:
    """Raise (or set) a key's cumulative spend ceiling."""
    resp = httpx.post(
        f"{LITELLM_BASE_URL}/key/update",
        headers=_HEADERS,
        json={"key": vk, "max_budget": max_budget},
        timeout=20,
    )
    resp.raise_for_status()


def key_info(vk: str) -> dict:
    """Return {spend, max_budget} for a key (authoritative usage numbers)."""
    resp = httpx.get(
        f"{LITELLM_BASE_URL}/key/info",
        headers=_HEADERS,
        params={"key": vk},
        timeout=20,
    )
    resp.raise_for_status()
    info = resp.json().get("info", {})
    return {
        "spend": float(info.get("spend") or 0),
        "max_budget": float(info.get("max_budget") or 0),
    }
