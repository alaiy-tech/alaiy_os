"""Image providers, called with this service's own credentials.

The two integrations here used to live on the bench, each reading its own key
out of site_config. They moved for the same reason the LiteLLM master key never
leaves this service: a credential on a customer's filesystem is a credential the
customer holds. Now a bench asks for the work and gets the result; it never sees
a provider key and cannot call either provider on its own account.

Why these are here rather than behind LiteLLM: alphashop is not an LLM API at all
— no model id, its own JWT auth, its own response contract — so no gateway can
front it, whatever providers the catalogue carries. That forces an image endpoint
onto this service regardless. Generation then sits beside it so both share one
credential holder and one metering path, rather than being metered two different
ways against the same balance.

So this module is the image-side equivalent of litellm_client.py: the one place a
provider's wire format is expressed.

Nothing here touches the database or the budget. Metering is the caller's job
(app/main.py), so a provider call and the money that follows it stay separable.
"""

import time
from datetime import datetime, timedelta, timezone

import httpx

from app.config import (
    ALPHASHOP_AK,
    ALPHASHOP_BASE_URL,
    ALPHASHOP_SK,
    IMAGE_GENERATE_MODEL,
    OPENROUTER_API_KEY,
)


class ProviderError(RuntimeError):
    """A provider refused or failed. Carries a message safe to show a bench."""


# --- OpenRouter image generation ---------------------------------------------
# OpenRouter's own Unified Image API. NOT the OpenAI Images REST API and not
# reachable with the OpenAI SDK — confirmed live, images.generate / images.edit
# both 404 against OpenRouter.
_OPENROUTER_IMAGES_URL = "https://openrouter.ai/api/v1/images"
_GENERATE_TIMEOUT = 180


def generate_image(prompt: str, reference_data_uri: str | None = None) -> dict:
    """One image from a prompt, optionally editing a reference photo.

    Returns {"b64": str, "media_type": str, "usage": dict}. The reference, when
    given, is a data: URI — the bench resolves and encodes the photo, because
    only it can read its own Frappe Files.
    """
    if not OPENROUTER_API_KEY:
        raise ProviderError("image generation is not configured (no OPENROUTER_API_KEY)")

    payload: dict = {
        "model": IMAGE_GENERATE_MODEL,
        "prompt": prompt,
        "n": 1,
        "output_format": "png",
    }
    if reference_data_uri:
        payload["input_references"] = [
            {"type": "image_url", "image_url": {"url": reference_data_uri}}
        ]

    try:
        resp = httpx.post(
            _OPENROUTER_IMAGES_URL,
            headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
            json=payload,
            timeout=_GENERATE_TIMEOUT,
        )
    except httpx.HTTPError as exc:
        raise ProviderError(f"image generation request failed: {exc}") from exc

    if resp.status_code != 200:
        raise ProviderError(
            f"image generation failed ({resp.status_code}): {resp.text[:500]}"
        )

    data = resp.json()
    try:
        image = data["data"][0]
        return {
            "b64": image["b64_json"],
            "media_type": image.get("media_type", "image/png"),
            "usage": data.get("usage", {}),
        }
    except (KeyError, IndexError) as exc:
        raise ProviderError(f"unexpected image generation response: {str(data)[:300]}") from exc


# --- alphashop image translation ---------------------------------------------
# Chinese text printed on supplier photos -> English, via ai.image.translateImage.
# Auth is a short-lived HS256 JWT signed with the secret key and issued by the
# access key.
#
# IMPORTANT: alphashop fetches the image ITSELF from the imageUrl we send, so
# that URL must be reachable from alphashop's servers. Supplier CDN URLs (the
# normal case) work as-is. This service does not proxy the bytes.
_ALPHASHOP_TRANSLATE_PATH = "/ai.image.translateImage/1.0"
_JWT_TTL_SECONDS = 1800
_JWT_LEEWAY_SECONDS = 5
_TRANSLATE_TIMEOUT = 30
_TRANSLATE_MAX_RETRIES = 3
_TRANSLATE_RETRY_DELAYS = (2, 4, 8)


def _alphashop_headers() -> dict:
    """Auth headers for alphashop.

    The token is minted per attempt rather than reused, so a retry after a long
    backoff never sends one that has since expired.
    """
    import jwt

    now = datetime.now(timezone.utc)
    token = jwt.encode(
        {
            "iss": ALPHASHOP_AK,
            "exp": now + timedelta(seconds=_JWT_TTL_SECONDS),
            "nbf": now - timedelta(seconds=_JWT_LEEWAY_SECONDS),
        },
        ALPHASHOP_SK,
        algorithm="HS256",
        headers={"alg": "HS256"},
    )
    if isinstance(token, bytes):
        token = token.decode("utf-8")
    return {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}


def translate_image(image_url: str) -> str:
    """One photo through alphashop. Returns the URL of the translated image.

    This is the ONLY place the alphashop request/response contract is expressed.
    The response nests the payload two levels deep — result.result — with the
    outer block carrying retCode/retMsg when the call fails logically despite a
    200. Retries with exponential backoff; raises once retries are exhausted so
    the caller can record the failure against that one photo.

    The translated URL is alphashop's and may expire. Re-hosting it is the
    bench's job, since the bench owns the File store.
    """
    if not ALPHASHOP_AK or not ALPHASHOP_SK:
        raise ProviderError("image translation is not configured (no ALPHASHOP_AK/SK)")

    endpoint = ALPHASHOP_BASE_URL.rstrip("/") + _ALPHASHOP_TRANSLATE_PATH
    body = {
        "imageUrl": image_url,
        "sourceLanguage": "zh",
        "targetLanguage": "en",
        "includingProductArea": True,
        "useImageEditor": True,
        "translatingBrandInTheProduct": True,
    }

    last_err = None
    for attempt in range(_TRANSLATE_MAX_RETRIES):
        try:
            resp = httpx.post(
                endpoint, headers=_alphashop_headers(), json=body, timeout=_TRANSLATE_TIMEOUT
            )
            if not (resp.headers.get("Content-Type") or "").startswith("application/json"):
                raise ProviderError(f"non-JSON response: {resp.text[:200]}")

            data = resp.json()
            result_block = data.get("result")
            if not isinstance(result_block, dict):
                # A null result with a top-level resultCode is how alphashop
                # reports most failures. FAIL_SERVER_INTERNAL_ERROR in particular
                # is what you get when it could not fetch `imageUrl` at all — so
                # say so, since the code alone points at their server rather than
                # at our unreachable URL.
                code = data.get("resultCode") or "unknown"
                hint = ""
                if code == "FAIL_SERVER_INTERNAL_ERROR":
                    hint = (
                        f" — most often this means alphashop could not fetch the image;"
                        f" check that {image_url} is publicly reachable and returns an image"
                    )
                raise ProviderError(f"{code} (requestId={data.get('requestId')}){hint}")

            translated = (result_block.get("result") or {}).get("translatedImageUrl")
            if not translated:
                raise ProviderError(
                    f"no translatedImageUrl (retCode={result_block.get('retCode')}, "
                    f"retMsg={result_block.get('retMsg', 'Unknown error')})"
                )
            return translated

        except Exception as exc:
            last_err = exc
            if attempt < _TRANSLATE_MAX_RETRIES - 1:
                time.sleep(
                    _TRANSLATE_RETRY_DELAYS[min(attempt, len(_TRANSLATE_RETRY_DELAYS) - 1)]
                )

    raise ProviderError(
        f"alphashop translate failed after {_TRANSLATE_MAX_RETRIES} attempts: {last_err}"
    )
