"""Alaiy OS Billing Service — control plane.

Sole holder of the LiteLLM master key and all Razorpay credentials. Benches
receive only their own scoped data-plane key and a per-bench token; all money
logic (markup, ledger, budget sync, payment verification) lives here.

Auth model:
  /provision            shared BOOTSTRAP_TOKEN; issues a per-bench token.
  /topup/order,/verify  per-bench token; site derived from the token.
  /razorpay/webhook     no bench auth — authenticated by Razorpay's signature.
  /balance              per-bench token.
  /image/*              per-bench token; site derived from the token.

Image endpoints:
  Text goes through LiteLLM, which meters itself against the virtual key. Image
  work is served from here instead: alphashop is not an LLM and no gateway can
  front it, so an image endpoint on this service is required whatever the
  catalogue carries — and generation sits beside it so both share one credential
  holder and one metering path. Called with our own credentials
  (app/providers.py) and metered by hand against the same budget. See _charge().

Payment modes:
  - Razorpay enabled (keys set): /topup/order makes a real order; credit happens
    via /topup/verify (Checkout callback) and/or /razorpay/webhook (production).
  - Mock (no keys): /topup/order mints a fake order; /topup/confirm credits it.
"""

import json
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

from app import db, litellm_client, providers, razorpay_client
from app.config import (
    ALLOWED_MODELS,
    BOOTSTRAP_TOKEN,
    GATEWAY_URL_FOR_BENCH,
    IMAGE_GENERATE_COST_USD,
    IMAGE_TRANSLATE_COST_USD,
    INITIAL_BUDGET_USD,
    MARKUP,
    RAZORPAY_KEY_ID,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="Alaiy OS Billing Service", lifespan=lifespan)


def _bearer(authorization: str | None) -> str:
    return (authorization or "").removeprefix("Bearer ").strip()


def _hash(token: str) -> str:
    import hashlib

    return hashlib.sha256(token.encode()).hexdigest()


def _require_bootstrap(authorization: str | None):
    if _bearer(authorization) != BOOTSTRAP_TOKEN or not BOOTSTRAP_TOKEN:
        raise HTTPException(status_code=401, detail="invalid bootstrap token")


def _site_from_token(authorization: str | None) -> str:
    token = _bearer(authorization)
    site = db.site_for_token(_hash(token)) if token else None
    if not site:
        raise HTTPException(status_code=401, detail="invalid bench token")
    return site


def _balance_usd(max_budget_usd: float, spend_usd: float) -> float:
    """Customer-facing balance in USD: remaining real budget × markup, so it
    reads back in the paid value. USD is the only currency in play — the bench
    displays this figure as-is."""
    remaining_usd = max(0.0, max_budget_usd - spend_usd)
    return round(remaining_usd * MARKUP, 2)


def _balance_for(site: str) -> dict:
    bench = db.get_bench(site)
    if not bench:
        raise HTTPException(status_code=404, detail="bench not provisioned")
    info = litellm_client.key_info(bench["vk"])
    return {"site": site, "balance_usd": _balance_usd(info["max_budget"], info["spend"])}


def _sync_budget(site: str) -> None:
    """Push the site's real budget ceiling to LiteLLM.

    The ceiling is always recomputed from scratch —

        initial + everything credited - everything spent outside the gateway

    — rather than adjusted by a delta. That is what makes it safe for two
    concurrent image calls to both land here: each one recomputes from the
    append-only tables, so whichever writes last still writes the correct total.
    A read-modify-write of LiteLLM's own max_budget would lose one of them.

    LiteLLM subtracts its own token spend from this ceiling on its side, so image
    spend riding in as a REDUCTION of the ceiling keeps both kinds of usage
    against one number — and /balance keeps working untouched.
    """
    bench = db.get_bench(site)
    if not bench:
        raise HTTPException(status_code=404, detail="bench not provisioned")
    ceiling = (
        bench["initial_budget_usd"] + db.total_credited_usd(site) - db.total_usage_usd(site)
    )
    litellm_client.set_budget(bench["vk"], max(0.0, round(ceiling, 6)))


def _require_credit(site: str) -> None:
    """Refuse a paid image call when the site is out of credit.

    Checked BEFORE the provider call. LiteLLM enforces this for itself on the
    token path; nothing enforces it for images except this.
    """
    if _balance_for(site)["balance_usd"] <= 0:
        raise HTTPException(
            status_code=402,
            detail="AI credits exhausted. Please top up to continue.",
        )


def _charge(site: str, kind: str, units: int, unit_cost_usd: float) -> None:
    """Record image spend and lower the site's ceiling by it.

    Called only AFTER the provider delivered: a failed image is not billed. The
    usage row is written first so a crash between the two leaves the money
    recorded rather than lost — the next _sync_budget picks it up.
    """
    if units <= 0 or unit_cost_usd <= 0:
        return
    db.add_usage(site, kind, units, round(units * unit_cost_usd, 6))
    _sync_budget(site)


def _credit_order(order_id: str, site: str) -> dict:
    """Apply a paid order to the ledger + raise the vk budget. Idempotent on
    order_id, so webhook and callback both firing never double-credits."""
    order = db.get_order(order_id)
    if not order or order["site"] != site:
        raise HTTPException(status_code=404, detail="unknown order")
    if db.ledger_for_order(order_id):
        return {"status": "already_processed", **_balance_for(site)}

    credited_usd = order["amount_usd"] / MARKUP  # markup applied here, only here
    db.add_ledger(order_id, site, order["amount_usd"], credited_usd)
    db.mark_order_paid(order_id)

    # Recomputed from the ledgers rather than added on top, so a top-up cannot
    # silently refund image spend already recorded against this site.
    _sync_budget(site)
    return {"status": "success", **_balance_for(site)}


class ProvisionReq(BaseModel):
    site: str


class OrderReq(BaseModel):
    amount: float              # top-up amount, USD — the only currency we take
    # Accepted only so a caller that still sends it fails loudly rather than
    # having, say, an INR amount silently charged as USD. There is no fx here.
    currency: str = "USD"


class ConfirmReq(BaseModel):
    order_id: str


class VerifyReq(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str


class ImageGenerateReq(BaseModel):
    prompt: str
    # data: URI of the photo being edited. The bench encodes it, because only the
    # bench can read its own Frappe Files.
    reference_data_uri: str | None = None


class ImageTranslateReq(BaseModel):
    # Must be reachable from alphashop's servers — they fetch it themselves.
    image_url: str


@app.get("/health")
def health():
    return {"ok": True, "razorpay": razorpay_client.enabled()}


@app.post("/provision")
def provision(req: ProvisionReq, authorization: str | None = Header(default=None)):
    _require_bootstrap(authorization)
    import secrets

    existing = db.get_bench(req.site)
    if existing:
        vk, reused = existing["vk"], True
    else:
        vk = litellm_client.create_virtual_key(req.site, INITIAL_BUDGET_USD)
        db.create_bench(req.site, vk, INITIAL_BUDGET_USD)
        reused = False

    bench_token = secrets.token_urlsafe(32)
    db.set_bench_token(_hash(bench_token), req.site)
    return {
        "gateway_url": GATEWAY_URL_FOR_BENCH,
        "key": vk,
        "bench_token": bench_token,
        # The global whitelist, so a bench knows what it may call without
        # having to probe the gateway.
        "models": ALLOWED_MODELS,
        "reused": reused,
    }


@app.post("/topup/order")
def topup_order(req: OrderReq, authorization: str | None = Header(default=None)):
    site = _site_from_token(authorization)
    if req.currency.upper() != "USD":
        raise HTTPException(status_code=400, detail="only USD top-ups are supported")
    if req.amount <= 0:
        raise HTTPException(status_code=400, detail="amount must be positive")

    if razorpay_client.enabled():
        order = razorpay_client.create_order(req.amount, {"site": site})
        order_id, key_id = order["id"], RAZORPAY_KEY_ID
    else:
        order_id, key_id = f"order_mock_{uuid.uuid4().hex[:16]}", "rzp_test_mock"

    db.create_order(order_id, site, req.amount)
    return {
        "order_id": order_id,
        "amount": req.amount,
        "currency": "USD",
        "key_id": key_id,
    }


@app.post("/topup/verify")
def topup_verify(req: VerifyReq, authorization: str | None = Header(default=None)):
    """Credit from a Razorpay Checkout success callback (signature-verified)."""
    site = _site_from_token(authorization)
    if not razorpay_client.verify_payment_signature(req.model_dump()):
        raise HTTPException(status_code=400, detail="invalid payment signature")
    return _credit_order(req.razorpay_order_id, site)


@app.post("/topup/confirm")
def topup_confirm(req: ConfirmReq, authorization: str | None = Header(default=None)):
    """Mock-only credit path. Disabled when Razorpay is configured, so real
    deployments can't credit without a verified payment."""
    if razorpay_client.enabled():
        raise HTTPException(status_code=400, detail="mock confirm disabled; use real checkout")
    site = _site_from_token(authorization)
    return _credit_order(req.order_id, site)


@app.post("/razorpay/webhook")
async def razorpay_webhook(request: Request, x_razorpay_signature: str | None = Header(default=None)):
    """Production credit path: Razorpay -> billing, authenticated by signature.
    Site is resolved from our own order record, never trusted from the payload."""
    body = await request.body()
    if not razorpay_client.verify_webhook_signature(body, x_razorpay_signature):
        raise HTTPException(status_code=400, detail="invalid webhook signature")

    payload = json.loads(body)
    entity = payload.get("payload", {})
    order_id = None
    if "payment" in entity:
        order_id = entity["payment"]["entity"].get("order_id")
    elif "order" in entity:
        order_id = entity["order"]["entity"].get("id")

    order = db.get_order(order_id) if order_id else None
    if not order:
        return {"status": "ignored"}          # unknown/irrelevant event
    return _credit_order(order_id, order["site"])


@app.get("/balance")
def balance(authorization: str | None = Header(default=None)):
    return _balance_for(_site_from_token(authorization))


# --- Image work (off-gateway, metered here) ----------------------------------
# Both endpoints follow the same shape: check credit, call the provider, bill
# only on success. A provider failure returns 502 and costs the customer nothing,
# which matters because the bench renders images in bulk and treats a single
# failure as one lost image rather than a failed product.


@app.post("/image/generate")
def image_generate(req: ImageGenerateReq, authorization: str | None = Header(default=None)):
    """One generated image. Returns {b64, media_type, usage}."""
    site = _site_from_token(authorization)
    _require_credit(site)

    try:
        result = providers.generate_image(req.prompt, req.reference_data_uri)
    except providers.ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    _charge(site, "image_generate", 1, IMAGE_GENERATE_COST_USD)
    return result


@app.post("/image/translate")
def image_translate(req: ImageTranslateReq, authorization: str | None = Header(default=None)):
    """One translated photo. Returns {translated_url}.

    The URL is alphashop's and may expire — the bench re-hosts it, since the
    bench owns the File store and this service holds no image bytes.
    """
    site = _site_from_token(authorization)
    _require_credit(site)

    try:
        translated_url = providers.translate_image(req.image_url)
    except providers.ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    _charge(site, "image_translate", 1, IMAGE_TRANSLATE_COST_USD)
    return {"translated_url": translated_url}
