"""Billing service configuration (env-driven).

This service is the control plane: it is the ONLY holder of the LiteLLM master
key. Benches never see it — they receive only their own scoped virtual key.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")

# --- LiteLLM control plane ---------------------------------------------------
LITELLM_BASE_URL = os.environ.get("LITELLM_BASE_URL", "http://localhost:4000")
LITELLM_MASTER_KEY = os.environ.get("LITELLM_MASTER_KEY", "sk-1234")

# URL benches use to reach the gateway (data plane). Same as the base URL for
# local dev; in prod this is the public LiteLLM endpoint.
GATEWAY_URL_FOR_BENCH = os.environ.get("GATEWAY_URL_FOR_BENCH", LITELLM_BASE_URL)

# --- Bench-facing auth -------------------------------------------------------
# Shared secret a bench presents to /provision. Much narrower than the master
# key: it only authorizes "provision my own bench". Injected into the bench's
# site config before app install.
BOOTSTRAP_TOKEN = os.environ.get("BILLING_BOOTSTRAP_TOKEN", "dev-bootstrap-token")

# --- Provisioning defaults ---------------------------------------------------
# Budget granted to a freshly provisioned key. Dev default is a small trial so
# the key is immediately usable; set 0 for "must top up before any usage".
INITIAL_BUDGET_USD = float(os.environ.get("INITIAL_BUDGET_USD", "1.0"))

# --- Top-up / pricing --------------------------------------------------------
# Everything is USD: customers pay USD and see a USD balance. MARKUP is the
# vendor margin — real budget granted = amount_paid / MARKUP (pay $100 -> $25 of
# real usage), and the displayed balance is real_remaining * MARKUP (so it reads
# back in the paid value). Lives ONLY here; the bench never sees it.
MARKUP = float(os.environ.get("MARKUP", "4"))

# --- Razorpay ----------------------------------------------------------------
# When KEY_ID + KEY_SECRET are set, real orders/verification are used; otherwise
# the service runs in mock mode (dev). WEBHOOK_SECRET is only needed for the
# production server-to-server webhook. All three live ONLY here, never on a bench.
RAZORPAY_KEY_ID = os.environ.get("RAZORPAY_KEY_ID", "")
RAZORPAY_KEY_SECRET = os.environ.get("RAZORPAY_KEY_SECRET", "")
RAZORPAY_WEBHOOK_SECRET = os.environ.get("RAZORPAY_WEBHOOK_SECRET", "")

# Optional global narrowing of what a bench virtual key may call. Names must
# match model_names in gateway/config.yaml.
#
# Blank (the default) means "every model in the gateway catalogue", which is the
# intended setup: the catalogue is generated with an explicit price on every
# entry, so anything reachable is priced and no call can bill $0. Curating a
# second list here buys no billing safety — set it only if you actually want to
# withhold models a bench could otherwise reach.
ALLOWED_MODELS = [
    m.strip() for m in os.environ.get("ALLOWED_MODELS", "").split(",") if m.strip()
]

# --- Image providers ---------------------------------------------------------
# Image work is served from here rather than through the gateway. The reason is
# alphashop: it is not an LLM at all — no model id, no chat/completions or images
# wire format, its own JWT auth — so LiteLLM cannot front it whatever providers
# the catalogue carries. An image endpoint on this service is therefore required
# regardless of how the gateway is configured.
#
# Given that, generation sits beside it so there is ONE credential holder, ONE
# metering path and ONE budget. Splitting them would mean translation metered by
# hand here and generation metered by LiteLLM — two mechanisms writing to the
# same balance, which is the bug this arrangement avoids.
#
# (A secondary, changeable fact: the catalogue carries no image model today. If
# it gains one, generation COULD be re-pointed at the gateway — nothing on a
# bench would change, since it only ever sees the ai_client seam. That would be a
# deliberate trade of the single metering path for LiteLLM's own accounting.)
#
# Both keys live ONLY here. A bench holds neither.
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
IMAGE_GENERATE_MODEL = os.environ.get("IMAGE_GENERATE_MODEL", "openai/gpt-image-1")

ALPHASHOP_AK = os.environ.get("ALPHASHOP_AK", "")
ALPHASHOP_SK = os.environ.get("ALPHASHOP_SK", "")
ALPHASHOP_BASE_URL = os.environ.get("ALPHASHOP_BASE_URL", "https://api.alphashop.cn")

# Per-image cost in real USD, charged against the site's budget the same way
# LiteLLM's token spend is.
#
# These are flat per-image prices, deliberately, and they are the image-side
# equivalent of the "every model carries an explicit price" invariant in
# gateway/build_config.py: a provider whose price is 0 here would be billable
# upstream but free to the customer. Neither provider reports a cost we could
# fall back on — alphashop reports none at all, and an image model's usage block
# does not map onto what it actually charges — so an explicit number is the only
# honest option. Keep them in step with what the providers actually charge;
# nothing else will surface drift.
IMAGE_GENERATE_COST_USD = float(os.environ.get("IMAGE_GENERATE_COST_USD", "0.04"))
IMAGE_TRANSLATE_COST_USD = float(os.environ.get("IMAGE_TRANSLATE_COST_USD", "0.02"))

DB_PATH = os.environ.get("BILLING_DB_PATH", "billing.db")
