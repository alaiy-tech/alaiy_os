"""SQLite persistence.

Billing is USD end to end — customers are charged USD, Razorpay orders are
raised in USD, and balances are USD. There is no currency conversion anywhere.
The orders table keeps `amount`/`currency` alongside `amount_usd` only so rows
written before the USD-only switch stay readable; new rows are all USD.

Tables:
  bench        — site -> virtual key mapping (provisioning)
  bench_token  — per-bench token (hash) -> site
  orders       — top-up orders
  ledger       — append-only credits; source of truth for money in.
                 One row per paid order (order_id UNIQUE) → double-confirm is a no-op.
  usage        — append-only debits for work billed OUTSIDE LiteLLM (image
                 generation, image translation). Money out, in real USD.
                 LiteLLM tracks its own token spend against the virtual key, so
                 this table covers only what never touches the gateway.
"""

import sqlite3
from contextlib import contextmanager

from app.config import DB_PATH


@contextmanager
def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _cols(c, table):
    return [r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()]


def init_db():
    with _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS bench (
                site               TEXT PRIMARY KEY,
                vk                 TEXT NOT NULL,
                initial_budget_usd REAL NOT NULL,
                created_at         TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS orders (
                order_id   TEXT PRIMARY KEY,
                site       TEXT NOT NULL,
                amount     REAL NOT NULL,
                currency   TEXT NOT NULL DEFAULT 'USD',
                amount_usd REAL NOT NULL,
                status     TEXT NOT NULL DEFAULT 'created',
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS ledger (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id     TEXT NOT NULL UNIQUE,
                site         TEXT NOT NULL,
                amount_usd   REAL NOT NULL,
                credited_usd REAL NOT NULL,
                created_at   TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS bench_token (
                token_hash TEXT PRIMARY KEY,
                site       TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS usage (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                site       TEXT NOT NULL,
                kind       TEXT NOT NULL,
                units      INTEGER NOT NULL,
                cost_usd   REAL NOT NULL,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS usage_site ON usage (site)")
        _migrate(c)


def _migrate(c):
    """Bring a pre-USD (INR) schema up to date without losing data."""
    ocols = _cols(c, "orders")
    if "amount_inr" in ocols and "amount" not in ocols:
        c.execute("ALTER TABLE orders RENAME COLUMN amount_inr TO amount")
    if "currency" not in _cols(c, "orders"):
        c.execute("ALTER TABLE orders ADD COLUMN currency TEXT NOT NULL DEFAULT 'USD'")
    if "amount_usd" not in _cols(c, "orders"):
        c.execute("ALTER TABLE orders ADD COLUMN amount_usd REAL NOT NULL DEFAULT 0")
    lcols = _cols(c, "ledger")
    if "amount_inr" in lcols and "amount_usd" not in lcols:
        c.execute("ALTER TABLE ledger RENAME COLUMN amount_inr TO amount_usd")


# --- bench -------------------------------------------------------------------
def get_bench(site):
    with _conn() as c:
        row = c.execute("SELECT * FROM bench WHERE site = ?", (site,)).fetchone()
        return dict(row) if row else None


def create_bench(site, vk, budget):
    with _conn() as c:
        c.execute(
            "INSERT INTO bench (site, vk, initial_budget_usd) VALUES (?, ?, ?)",
            (site, vk, budget),
        )


# --- orders ------------------------------------------------------------------
def create_order(order_id, site, amount_usd):
    """Orders are USD-only. `amount` and `currency` are kept because historical
    rows may hold another currency; new rows always write USD."""
    with _conn() as c:
        c.execute(
            "INSERT INTO orders (order_id, site, amount, currency, amount_usd) "
            "VALUES (?, ?, ?, 'USD', ?)",
            (order_id, site, amount_usd, amount_usd),
        )


def get_order(order_id):
    with _conn() as c:
        row = c.execute("SELECT * FROM orders WHERE order_id = ?", (order_id,)).fetchone()
        return dict(row) if row else None


def mark_order_paid(order_id):
    with _conn() as c:
        c.execute("UPDATE orders SET status = 'paid' WHERE order_id = ?", (order_id,))


# --- ledger ------------------------------------------------------------------
def ledger_for_order(order_id):
    with _conn() as c:
        row = c.execute("SELECT * FROM ledger WHERE order_id = ?", (order_id,)).fetchone()
        return dict(row) if row else None


def add_ledger(order_id, site, amount_usd, credited_usd):
    with _conn() as c:
        c.execute(
            "INSERT INTO ledger (order_id, site, amount_usd, credited_usd) "
            "VALUES (?, ?, ?, ?)",
            (order_id, site, amount_usd, credited_usd),
        )


def total_credited_usd(site):
    with _conn() as c:
        row = c.execute(
            "SELECT COALESCE(SUM(credited_usd), 0) AS total FROM ledger WHERE site = ?",
            (site,),
        ).fetchone()
        return float(row["total"])


# --- usage (non-LiteLLM spend) -----------------------------------------------
def add_usage(site, kind, units, cost_usd):
    """Record work billed outside the gateway. Append-only, like `ledger`."""
    with _conn() as c:
        c.execute(
            "INSERT INTO usage (site, kind, units, cost_usd) VALUES (?, ?, ?, ?)",
            (site, kind, units, cost_usd),
        )


def total_usage_usd(site):
    with _conn() as c:
        row = c.execute(
            "SELECT COALESCE(SUM(cost_usd), 0) AS total FROM usage WHERE site = ?",
            (site,),
        ).fetchone()
        return float(row["total"])


# --- bench tokens ------------------------------------------------------------
def set_bench_token(token_hash, site):
    with _conn() as c:
        c.execute("DELETE FROM bench_token WHERE site = ?", (site,))
        c.execute(
            "INSERT INTO bench_token (token_hash, site) VALUES (?, ?)",
            (token_hash, site),
        )


def site_for_token(token_hash):
    with _conn() as c:
        row = c.execute(
            "SELECT site FROM bench_token WHERE token_hash = ?", (token_hash,)
        ).fetchone()
        return row["site"] if row else None
