"""
Alaiy OS — provisioning logic.

Runs on after_install (fresh install) and after_migrate (every deploy).
Reconciles the site's workspace, branding and company to match this codebase.

Only genuinely dynamic reconciliation lives here — state that depends on
runtime DB content (which connectors are registered, the site's company
name) or on other apps' hooks. Static, one-time seed data (the OS Manager
role, the Item custom fields backing the shared connector doctypes) is
declared in hooks.py's `fixtures` list instead and synced automatically by
Frappe's own fixtures mechanism on every bench migrate — see
alaiy_os/fixtures/*.json. Module Def needs no provisioning code at all:
Frappe creates it automatically from modules.txt.

Data definitions:
  constants/roles.py       — OS_MANAGER_ROLE
  constants/workspace.py   — WORKSPACE_NAME, shortcuts, links, sidebar items
  constants/onboarding.py  — ONBOARDING_NAME, ONBOARDING_STEPS
"""

import hashlib
import json
import os
from contextlib import contextmanager

import frappe

from alaiy_os.constants.roles import OS_MANAGER_ROLE
from alaiy_os.constants.workspace import (
    WORKSPACE_NAME,
    WORKSPACE_ROUTE,
    WORKSPACE_SHORTCUTS,
    WORKSPACE_LINKS,
    WORKSPACE_SIDEBAR_ITEMS,
    WORKSPACE_SIDEBAR_SETTINGS_ITEM,
)
from alaiy_os.constants.workspace_settings import (
    SETTINGS_WORKSPACE_NAME,
    SETTINGS_WORKSPACE_ROUTE,
    SETTINGS_WORKSPACE_LINKS,
    SETTINGS_WORKSPACE_SIDEBAR_ITEMS,
)
from alaiy_os.constants.onboarding import ONBOARDING_NAME, ONBOARDING_STEPS
from alaiy_os.alaiy_os.doctype.os_connector_registry.os_connector_registry import _HANDLER_FIELDS
from alaiy_os.assistant_tools.permissions import ensure_roles as _ensure_assistant_roles

MODULE_NAME = "Alaiy OS"


# ── Entry points ──────────────────────────────────────────────────────────────

def after_install():
    _run_provisioning()


def after_migrate():
    _run_provisioning()


def _cleanup_legacy_workspace():
    OLD_NAMES = ["Alaiy OS"]
    for old in OLD_NAMES:
        if frappe.db.exists("Workspace Sidebar", old):
            frappe.delete_doc("Workspace Sidebar", old,
                              ignore_permissions=True, force=True)
        if frappe.db.exists("Workspace", old):
            frappe.delete_doc("Workspace", old,
                              ignore_permissions=True, force=True)


@contextmanager
def _provisioning_savepoint(name):
    """Runs one provisioning step's writes inside a SQL SAVEPOINT.

    All of _run_provisioning()'s steps share one uncommitted transaction —
    only the single frappe.db.commit() at the end of the loop actually
    persists anything. A plain frappe.db.rollback() in a step's except
    block would therefore undo every *other* step's already-succeeded
    writes too, not just the failing one. Rolling back to a per-step
    savepoint instead undoes only this step's own writes, leaving
    everything else pending exactly as if this step had never run.

    Re-raises on failure (unlike frappe.database.database.savepoint(),
    whose own context manager swallows the exception) so the caller's
    try/except still logs it and adds it to the failed-steps list.
    """
    frappe.db.savepoint(name)
    try:
        yield
    except Exception:
        frappe.db.rollback(save_point=name)
        raise
    else:
        try:
            frappe.db.release_savepoint(name)
        except Exception:
            # A DDL statement inside the step (e.g. create_custom_fields
            # altering a table for a new column) implicitly commits in
            # MySQL, which destroys the savepoint before we get here --
            # the step's writes already committed for real, so there is
            # nothing left to release. Confirmed live: this is exactly
            # what happened for ensure_sales_channel_field, which
            # succeeded but still showed up as a "failed" step.
            pass


def _run_provisioning():
    # Reset once per run so _connector_registry_rows() below fetches fresh
    # data on the first call this run, then reuses it for every other step.
    global _connector_registry_rows_cache
    _connector_registry_rows_cache = None

    steps = [
        skip_erpnext_onboarding,
        _cleanup_legacy_workspace,
        delete_desktop_page,
        create_or_update_workspace,
        create_or_update_workspace_sidebar,
        create_or_update_os_settings_workspace,
        create_or_update_os_settings_workspace_sidebar,
        restrict_foreign_workspaces,
        create_or_update_onboarding,
        ensure_default_logos,
        ensure_desktop_icon_logos,
        sync_custom_pages,
        configure_system_settings,
        configure_navbar,
        configure_portal_settings,
        check_dotted_path_handlers,
        ensure_sales_channel_field,
        ensure_assistant_roles,
    ]
    failed = []
    for step in steps:
        try:
            with _provisioning_savepoint(step.__name__):
                step()
        except Exception:
            failed.append(step.__name__)
            frappe.log_error(
                title=f"Alaiy OS: provisioning step {step.__name__} failed",
                message=frappe.get_traceback(),
            )
    frappe.db.commit()
    frappe.clear_cache()

    # Each step is independently try/except-wrapped above so one broken step
    # (e.g. a schema mismatch on an upgrade) never blocks the rest — but that
    # also means a failure is otherwise invisible outside the Error Log.
    # Print a summary so whoever ran bench migrate/install-app sees it.
    succeeded = len(steps) - len(failed)
    if failed:
        print(
            f"Alaiy OS: {succeeded}/{len(steps)} provisioning steps succeeded; "
            f"see Error Log for: {', '.join(failed)}"
        )
    else:
        print(f"Alaiy OS: {succeeded}/{len(steps)} provisioning steps succeeded.")


# ── Sales channel field ─────────────────────────────────────────────────────

def ensure_sales_channel_field():
    """
    Sales Order.sales_channel -- confirmed live that Frappe's fixtures
    sync (frappe.utils.fixtures.sync_fixtures, driven by hooks.py's
    `fixtures` list) silently fails to create a genuinely NEW Custom Field
    row on some sites: no exception, no Error Log entry, and a re-run
    reproduces the same silent no-op even right after deleting the row.
    A plain frappe.get_doc({...}).insert() for the identical field
    definition succeeds immediately. create_custom_fields is the same
    reliable mechanism every connector app in this codebase already uses
    for its own custom fields -- used here instead of trusting the
    fixtures path for this one.

    The field stays declared in hooks.py's fixtures list too (harmless,
    and correct for sites where the fixtures path does work); this is a
    belt-and-suspenders guarantee, not a replacement for it.
    """
    if not frappe.db.exists("DocType", "Sales Order"):
        return
    from frappe.custom.doctype.custom_field.custom_field import create_custom_fields
    create_custom_fields({
        "Sales Order": [
            {
                "fieldname": "sales_channel",
                "label": "Sales Channel",
                "fieldtype": "Data",
                "read_only": 1,
                "in_list_view": 1,
                "in_standard_filter": 1,
                "insert_after": "order_type",
                "description": "Channel this order originated from. Set by the connector that imported it; blank for orders raised directly in AlaiyOS.",
            },
        ],
    }, update=True)


def skip_erpnext_onboarding():
    """
    Mark the ERPNext setup wizard as complete so it never pops up.
    Also marks all Module Onboarding records for ERPNext modules as complete
    so the Getting Started banners are suppressed.
    """
    frappe.db.set_default("setup_complete", 1)

    if frappe.db.exists("DocType", "System Settings"):
        try:
            meta = frappe.get_meta("System Settings")
            if meta.has_field("setup_complete"):
                frappe.db.set_single_value(
                    "System Settings", "setup_complete", 1)
        except Exception:
            pass

    for dt in ("Setup Progress", "ERPNext Settings"):
        if not frappe.db.exists("DocType", dt):
            continue
        try:
            meta = frappe.get_meta(dt)
            if meta.has_field("setup_complete"):
                frappe.db.set_single_value(dt, "setup_complete", 1)
        except Exception:
            pass

    for name in frappe.get_all("Module Onboarding", pluck="name"):
        if name == ONBOARDING_NAME:
            continue
        try:
            frappe.db.set_value("Module Onboarding", name, "is_complete", 1)
        except Exception:
            pass

    if frappe.db.exists("DocType", "User") and frappe.db.has_column("User", "onboarding_status"):
        frappe.db.sql(
            "UPDATE tabUser SET onboarding_status = 'Skipped' WHERE onboarding_status IS NULL OR onboarding_status = ''")


# ── Desktop page removal ───────────────────────────────────────────────────────

def delete_desktop_page():
    """
    Delete the stock Frappe "desktop" Page outright. /desk itself keeps
    landing on the OS workspace regardless (see setup/boot.py::on_login),
    this just removes the old default-desktop route entirely.
    """
    if not frappe.db.exists("Page", "desktop"):
        return
    # Page.on_trash() throws outside developer mode unless this flag is set —
    # Frappe core's own drop_unused_pages patch relies on the same toggle.
    frappe.flags.in_migrate = True
    try:
        frappe.delete_doc("Page", "desktop", ignore_permissions=True, force=True)
    finally:
        frappe.flags.in_migrate = False


# ── Foreign workspace restriction ───────────────────────────────────────────────

def _foreign_workspace_allowlist():
    """
    Workspace names and/or owning-app names that restrict_foreign_workspaces()
    (and the Welcome Workspace hard-delete alongside it) should leave alone —
    entries aren't distinguished as "name" vs "app"; a Workspace is skipped if
    either its own name or its owning app matches any entry. Populated from:

      - site_config.json's "alaiy_os_foreign_workspace_allowlist" — a list,
        for a specific site's own exception (e.g. ["Welcome Workspace"] to
        keep the stock one on this site only).
      - the alaiy_os_foreign_workspace_allowlist hook, e.g. in another app's
        own hooks.py:
            alaiy_os_foreign_workspace_allowlist = ["some_app"]
        so an app can protect its own workspace regardless of which site
        it's installed on, without every site admin having to configure it.
    """
    entries = list(frappe.conf.get("alaiy_os_foreign_workspace_allowlist", []) or [])
    for hook_entries in frappe.get_hooks("alaiy_os_foreign_workspace_allowlist"):
        entries.extend(hook_entries if isinstance(hook_entries, list) else [hook_entries])
    return set(entries)


def _delete_welcome_workspace():
    """Hard-delete the stock "Welcome Workspace" (and its sidebar row, if
    any) — unlike every other foreign workspace, this one is removed
    outright rather than just hidden."""
    if frappe.db.exists("Workspace Sidebar", "Welcome Workspace"):
        frappe.delete_doc("Workspace Sidebar", "Welcome Workspace",
                           ignore_permissions=True, force=True)
    if frappe.db.exists("Workspace", "Welcome Workspace"):
        frappe.delete_doc("Workspace", "Welcome Workspace",
                           ignore_permissions=True, force=True)


def restrict_foreign_workspaces():
    """
    Hide every public Workspace not owned by alaiy_os (ERPNext's and
    Frappe's own Stock/Selling/Buying/HR/etc. workspaces) from the workspace
    switcher, Awesomebar search and desktop icons, and lock them to
    Administrator only. "Welcome Workspace" specifically is hard-deleted
    instead (see _delete_welcome_workspace()), not just hidden.

    Re-runs on every after_migrate so new workspaces introduced by future
    app/ERPNext updates get caught too. Our own workspaces (OS, OS Settings)
    are left untouched.

    Set "alaiy_os_restrict_foreign_workspaces": false in site_config.json to
    disable this step entirely on a given site — e.g. a site that genuinely
    wants another installed app's workspace to stay visible/editable by
    non-Administrator roles. For a narrower opt-out, see
    _foreign_workspace_allowlist().
    """
    if not frappe.conf.get("alaiy_os_restrict_foreign_workspaces", True):
        return

    allowlist = _foreign_workspace_allowlist()

    if "Welcome Workspace" not in allowlist:
        _delete_welcome_workspace()

    own_names = {WORKSPACE_NAME, SETTINGS_WORKSPACE_NAME}
    rows = frappe.get_all(
        "Workspace",
        filters={"public": 1},
        fields=["name", "app"],
    )
    for row in rows:
        if (
            row.name in own_names
            or row.app == "alaiy_os"
            or row.name == "Welcome Workspace"
            or row.name in allowlist
            or (row.app and row.app in allowlist)
        ):
            continue
        try:
            doc = frappe.get_doc("Workspace", row.name)
            doc.is_hidden = 1
            doc.set("roles", [{"role": "Administrator"}])
            doc.flags.ignore_validate = True
            doc.flags.ignore_links = True
            # No ignore_mandatory here: the one stock workspace known to ship
            # with legacy missing-mandatory-field data ("Welcome Workspace")
            # is hard-deleted above, before this loop ever sees it — nothing
            # left in this loop is a known-bad record, so this app shouldn't
            # blanket-bypass mandatory-field guarantees on documents it
            # doesn't own. If some other foreign workspace genuinely can't
            # save without it, that surfaces in the Error Log below instead
            # of being silently skipped.
            doc.save(ignore_permissions=True)
        except Exception:
            frappe.log_error(
                title=f"Alaiy OS: could not restrict workspace {row.name!r}",
                message=frappe.get_traceback(),
            )


# ── Default logos ──────────────────────────────────────────────────────────────

def ensure_default_logos():
    """
    Copy this app's bundled default logos into the site's shared (non-app-
    namespaced) assets folder as client-logo-square.png / client-logo-hor.png
    — only if those files don't already exist, so a fresh install gets sane
    defaults immediately without ever clobbering an admin's own upload made
    later via the OS Theme Settings page (alaiy_os/alaiy_os/doctype/os_theme_settings).
    """
    import shutil

    images_dir = os.path.join(frappe.local.sites_path, "assets", "images")
    os.makedirs(images_dir, exist_ok=True)

    pairs = [
        ("logo-square.png", "client-logo-square.png"),
        ("logo-hor.png", "client-logo-hor.png"),
    ]
    for source_name, dest_name in pairs:
        dest_path = os.path.join(images_dir, dest_name)
        if os.path.exists(dest_path):
            continue
        source_path = frappe.get_app_path("alaiy_os", "public", "images", source_name)
        if os.path.exists(source_path):
            shutil.copyfile(source_path, dest_path)


def ensure_desktop_icon_logos():
    """
    Point the OS / OS Settings app-switcher icons at the square logo instead
    of the lucide "layout-dashboard" glyph — that's what the sidebar header
    and the Getting Started popup fall back to (a plain grey letter avatar)
    when a Desktop Icon has no logo_url of its own.
    """
    logo_url = "/assets/images/client-logo-square.png"
    for workspace_name in (WORKSPACE_NAME, SETTINGS_WORKSPACE_NAME):
        if frappe.db.exists("Desktop Icon", workspace_name):
            frappe.db.set_value("Desktop Icon", workspace_name, "logo_url", logo_url)


def sync_custom_pages():
    """
    Page records (unlike DocType) aren't picked up by bench migrate's own
    "Updating DocTypes" sync just because the .json/.js files exist on disk —
    they need an explicit reload_doc, same as a core migration patch would do.
    """
    for page_name in ("ask_alaiy",):
        frappe.reload_doc("alaiy_os", "page", page_name)


# ── System Settings ────────────────────────────────────────────────────────────

def configure_system_settings():
    frappe.db.set_single_value("System Settings", "disable_system_update_notification", 1)


# ── Navbar Settings ─────────────────────────────────────────────────────────────

def configure_navbar():
    """
    Point the navbar logo at the site's client-hor-logo, clear the Settings
    dropdown entirely, and reset the Help dropdown to exactly two items
    (About Alaiy OS, Keyboard Shortcuts) — dropping the stock System
    Health / Frappe Support entries by simply not re-adding them.
    """
    navbar = frappe.get_single("Navbar Settings")
    navbar.app_logo = "/assets/images/client-logo-hor.png"
    navbar.set("settings_dropdown", [])
    navbar.set("help_dropdown", [])
    navbar.append("help_dropdown", {
        "item_label": "About Alaiy OS",
        "item_type": "Route",
        "route": "https://os.alaiy.com",
    })
    navbar.append("help_dropdown", {
        "item_label": "Keyboard Shortcuts",
        "item_type": "Action",
        "action": "frappe.ui.toolbar.show_shortcuts(event)",
    })
    navbar.flags.ignore_mandatory = True
    navbar.save(ignore_permissions=True)


# ── Portal Settings ─────────────────────────────────────────────────────────────

def configure_portal_settings():
    frappe.db.set_single_value("Portal Settings", "default_portal_home", "/desk/os")


# ── Workspace naming ──────────────────────────────────────────────────────────
#
# Frappe's URL for a Workspace is slug(Workspace.name) — there is no separate
# "route" field (an earlier version of this file assumed there was one; there
# isn't, so WORKSPACE_NAME/SETTINGS_WORKSPACE_NAME must stay exactly "OS" and
# "OS Settings" forever, or /desk/os and /desk/os-settings break). Workspace's
# own autoname is "field:label" — changing `label` on an existing doc renames
# it out from under WORKSPACE_NAME (this bit us once already), so `label`
# must ALSO stay fixed, same as `name`. Frappe also looks up a workspace's
# sidebar via frappe.boot.workspace_sidebar_item[Workspace.name.lower()] —
# keyed by name, not title — so the Workspace Sidebar's name must equal the
# Workspace's name too, which (since Workspace Sidebar autonames from its own
# title field) means the sidebar's title must also stay "OS"/"OS Settings".
#
# Company branding can ONLY be applied to Workspace.title — the one field
# that's genuinely independent of both docs' identity. In practice this means
# it doesn't reach the sidebar header dropdown or the page breadcrumb (both
# hardcoded by Frappe to Workspace.name specifically), only wherever else
# `.title` happens to be read.

def _get_default_company():
    company = (frappe.db.get_single_value(
        "Global Defaults", "default_company") or "").strip()
    if company:
        return company


def _get_os_workspace_title():
    company = _get_default_company()
    return f"{company} OS" if company else WORKSPACE_NAME


def _get_os_settings_workspace_title():
    company = _get_default_company()
    return f"{company} OS Settings" if company else SETTINGS_WORKSPACE_NAME


_connector_registry_rows_cache = None


def _connector_registry_rows():
    # Called independently by several _build_connector_* helpers within one
    # provisioning run; cache so that only costs one query per run instead of
    # one per caller. _run_provisioning() resets the cache before each run.
    global _connector_registry_rows_cache
    if _connector_registry_rows_cache is not None:
        return _connector_registry_rows_cache

    if not frappe.db.exists("DocType", "OS Connector Registry"):
        _connector_registry_rows_cache = []
        return _connector_registry_rows_cache

    rows = frappe.get_all(
        "OS Connector Registry",
        fields=["connector_id", "connector_name", "settings_doctype", "icon"],
        order_by="connector_name asc",
    )
    _connector_registry_rows_cache = [r for r in rows if r.get("settings_doctype")]
    return _connector_registry_rows_cache


def _connector_link_target(row):
    """A connector with its own Page (e.g. Shopify's custom dashboard page,
    named == connector_id) links there instead of straight to its settings
    DocType form."""
    if frappe.db.exists("Page", row.connector_id):
        return "Page", row.connector_id
    return "DocType", row.settings_doctype


def _build_connector_workspace_links():
    """Connectors card on the main OS workspace body: one Link per
    installed connector."""
    rows = [r for r in _connector_registry_rows()
            if frappe.db.exists("DocType", r.settings_doctype)]
    if not rows:
        return []
    links = [{"type": "Card Break", "label": "Connectors", "icon": "plug"}]
    for row in rows:
        link_type, link_to = _connector_link_target(row)
        links.append({
            "type": "Link", "link_type": link_type,
            "link_to": link_to, "label": row.connector_name,
        })
    return links


def _build_connector_settings_workspace_links():
    """Connectors card on the OS Settings workspace body: one Link per
    installed connector, straight to its settings DocType (not the Page
    dashboard -- this is the settings hub, not the operational one)."""
    rows = [r for r in _connector_registry_rows()
            if frappe.db.exists("DocType", r.settings_doctype)]
    if not rows:
        return []
    links = [{"type": "Card Break", "label": "Connectors", "icon": "plug"}]
    for row in rows:
        links.append({
            "type": "Link", "link_type": "DocType",
            "link_to": row.settings_doctype, "label": row.connector_name,
        })
    return links


def _build_connector_settings_sidebar_items():
    """Connectors section in the OS Settings sidebar: one Link per
    installed connector, straight to its settings DocType."""
    rows = [r for r in _connector_registry_rows()
            if frappe.db.exists("DocType", r.settings_doctype)]
    if not rows:
        return []
    items = [{"type": "Section Break", "label": "Connectors",
              "icon": "plug", "child": 0, "indent": 1}]
    for row in rows:
        items.append({
            "type": "Link", "link_type": "DocType", "link_to": row.settings_doctype,
            "label": row.connector_name, "child": 1, "icon": row.icon or "plug",
        })
    return items


def _connector_extra_sidebar_items(connector_id):
    """
    Extra sidebar rows (e.g. "Listings") a connector app wants under its own
    top-level section, beyond the automatic Dashboard link. Declared via:

        alaiy_os_sidebar_connector_items = [
            {"connector_id": "shopify", "label": "Listings",
             "link_type": "DocType", "link_to": "Shopify Product Listing",
             "icon": "list"},
        ]

    Nothing connector-specific lives in alaiy_os itself -- each connector
    app registers its own rows, filtered here by connector_id and by
    whether the target actually exists.
    """
    entries = []
    for hook_entries in frappe.get_hooks("alaiy_os_sidebar_connector_items"):
        for entry in (hook_entries if isinstance(hook_entries, list) else [hook_entries]):
            if entry.get("connector_id") != connector_id:
                continue
            link_type = entry.get("link_type", "DocType")
            link_to = (entry.get("link_to") or "").strip()
            if not link_to:
                continue
            if link_type == "DocType" and not frappe.db.exists("DocType", link_to):
                continue
            if link_type == "Page" and not frappe.db.exists("Page", link_to):
                continue
            entries.append({
                "type": "Link", "link_type": link_type, "link_to": link_to,
                "label": entry.get("label", link_to), "child": 1,
                "icon": entry.get("icon", "chevron-right"),
            })
    return entries


def _build_connector_sidebar_items():
    """
    Each installed connector gets its OWN top-level section in the main OS
    sidebar (sibling to Catalog, Inventory, Sales, ...) instead of being
    nested one level deeper under a shared "Connectors" heading. Every
    section always has a Dashboard link (the connector's Page if it has
    one, else its settings DocType); connector apps can add more rows
    (e.g. Listings) via the alaiy_os_sidebar_connector_items hook. No
    connector name is hard-coded here -- rows come from OS Connector
    Registry and each app's own hook.
    """
    rows = [r for r in _connector_registry_rows()
            if frappe.db.exists("DocType", r.settings_doctype)]
    if not rows:
        return []
    items = []
    for row in rows:
        items.append({"type": "Section Break", "label": row.connector_name,
                       "icon": row.icon or "plug", "child": 0, "indent": 1})
        link_type, link_to = _connector_link_target(row)
        items.append({
            "type": "Link", "link_type": link_type, "link_to": link_to,
            "label": "Dashboard", "child": 1, "icon": "layout-dashboard",
        })
        items.extend(_connector_extra_sidebar_items(row.connector_id))
    return items


def _build_log_items():
    """
    Logs section in the OS Settings sidebar. Connector apps register their
    log links via the alaiy_os_sidebar_log_items hook:

        alaiy_os_sidebar_log_items = [
            {"link_type": "DocType", "link_to": "Cloudstore Sync Log",
             "label": "Cloudstore Logs", "icon": "activity"}
        ]

    Items whose target DocType/Page hasn't been installed yet are skipped.
    """
    entries = []
    for hook_entries in frappe.get_hooks("alaiy_os_sidebar_log_items"):
        for entry in (hook_entries if isinstance(hook_entries, list) else [hook_entries]):
            link_type = entry.get("link_type", "DocType")
            link_to = (entry.get("link_to") or "").strip()
            if not link_to:
                continue
            if link_type == "DocType" and not frappe.db.exists("DocType", link_to):
                continue
            if link_type == "Page" and not frappe.db.exists("Page", link_to):
                continue
            entries.append({
                "type":      "Link",
                "link_type": link_type,
                "link_to":   link_to,
                "label":     entry.get("label", link_to),
                "child":     1,
                "icon":      entry.get("icon", "activity"),
            })
    if not entries:
        return []
    return [{"type": "Section Break", "label": "Logs",
             "icon": "file-clock", "child": 0, "indent": 1}] + entries


# ── Workspace ─────────────────────────────────────────────────────────────────

def _block_id(label):
    return hashlib.md5(f"alaiy-block-{label}".encode()).hexdigest()[:10]


def _build_workspace_content(links):
    blocks = []
    for s in WORKSPACE_SHORTCUTS:
        blocks.append({
            "id":   _block_id(f"sc:{s['label']}"),
            "type": "shortcut",
            "data": {"shortcut_name": s["label"], "col": 3},
        })
    for link in links:
        if link.get("type") == "Card Break":
            blocks.append({
                "id":   _block_id(f"card:{link['label']}"),
                "type": "card",
                "data": {"card_name": link["label"], "col": 4},
            })
    return json.dumps(blocks)


def create_or_update_workspace():
    links = list(WORKSPACE_LINKS) + _build_connector_workspace_links()
    content = _build_workspace_content(links)
    title = _get_os_workspace_title()

    if not frappe.db.exists("Workspace", WORKSPACE_NAME):
        ws = frappe.get_doc({
            "doctype":   "Workspace",
            # label is Workspace's autoname source (autoname="field:label") —
            # it MUST stay WORKSPACE_NAME, exactly like name, or Frappe
            # renames the doc out from under WORKSPACE_NAME on every save.
            "label":     WORKSPACE_NAME,
            "title":     title,
            "name":      WORKSPACE_NAME,
            "type":      "Workspace",
            "public":    1,
            "icon":      "layout-dashboard",
            "module":    MODULE_NAME,
            "app":       "alaiy_os",
            "content":   content,
            "roles":     [],
            "shortcuts": WORKSPACE_SHORTCUTS,
            "links":     links,
        })
        ws.flags.ignore_validate = True
        ws.insert(ignore_permissions=True)
    else:
        ws = frappe.get_doc("Workspace", WORKSPACE_NAME)
        ws.set("links", [])
        ws.set("shortcuts", [])
        for link in links:
            ws.append("links", link)
        for shortcut in WORKSPACE_SHORTCUTS:
            ws.append("shortcuts", shortcut)
        ws.label = WORKSPACE_NAME
        ws.title = title
        ws.icon = "layout-dashboard"
        ws.module = MODULE_NAME
        ws.app = "alaiy_os"
        ws.type = "Workspace"
        ws.public = 1
        ws.content = content
        ws.roles = []
        ws.flags.ignore_validate = True
        ws.save(ignore_permissions=True)


# ── Workspace Sidebar ─────────────────────────────────────────────────────────

def create_or_update_workspace_sidebar():
    items = (
        list(WORKSPACE_SIDEBAR_ITEMS)
        + _build_connector_sidebar_items()
        + [WORKSPACE_SIDEBAR_SETTINGS_ITEM]
    )
    # Title must stay == WORKSPACE_NAME: Workspace Sidebar autonames from
    # title, and that name must match the Workspace's own (fixed) name for
    # Frappe's client-side sidebar lookup to find it.
    common_fields = {
        "title":             WORKSPACE_NAME,
        "for_user":          "",
        "standard":          1,
        "app":               "alaiy_os",
        "module_onboarding": ONBOARDING_NAME,
    }

    if frappe.db.exists("Workspace Sidebar", WORKSPACE_NAME):
        sidebar = frappe.get_doc("Workspace Sidebar", WORKSPACE_NAME)
        for k, v in common_fields.items():
            sidebar.set(k, v)
        sidebar.set("items", [])
        for item in items:
            sidebar.append("items", item)
        sidebar.flags.ignore_links = True
        sidebar.save(ignore_permissions=True)
    else:
        sidebar = frappe.get_doc({
            "doctype": "Workspace Sidebar",
            **common_fields,
            "items":   items,
        })
        sidebar.flags.ignore_links = True
        sidebar.insert(ignore_permissions=True)


# ── OS Settings Workspace ─────────────────────────────────────────────────────

def _build_os_settings_content(links):
    blocks = []
    for link in links:
        if link.get("type") == "Card Break":
            blocks.append({
                "id":   _block_id(f"settings-card:{link['label']}"),
                "type": "card",
                "data": {"card_name": link["label"], "col": 4},
            })
    return json.dumps(blocks)


def create_or_update_os_settings_workspace():
    links = list(SETTINGS_WORKSPACE_LINKS) + _build_connector_settings_workspace_links()
    content = _build_os_settings_content(links)
    title = _get_os_settings_workspace_title()

    if not frappe.db.exists("Workspace", SETTINGS_WORKSPACE_NAME):
        ws = frappe.get_doc({
            "doctype": "Workspace",
            # label is Workspace's autoname source — must stay
            # SETTINGS_WORKSPACE_NAME, see create_or_update_workspace().
            "label":   SETTINGS_WORKSPACE_NAME,
            "title":   title,
            "name":    SETTINGS_WORKSPACE_NAME,
            "type":    "Workspace",
            "public":  1,
            "icon":    "settings",
            "module":  MODULE_NAME,
            "app":     "alaiy_os",
            "content": content,
            "roles":   [],
            "shortcuts": [],
            "links":   links,
        })
        ws.flags.ignore_validate = True
        ws.insert(ignore_permissions=True)
    else:
        ws = frappe.get_doc("Workspace", SETTINGS_WORKSPACE_NAME)
        ws.set("links", [])
        ws.set("shortcuts", [])
        for link in links:
            ws.append("links", link)
        ws.label = SETTINGS_WORKSPACE_NAME
        ws.title = title
        ws.icon = "settings"
        ws.module = MODULE_NAME
        ws.app = "alaiy_os"
        ws.type = "Workspace"
        ws.public = 1
        ws.content = content
        ws.roles = []
        ws.flags.ignore_validate = True
        ws.save(ignore_permissions=True)


def create_or_update_os_settings_workspace_sidebar():
    items = list(SETTINGS_WORKSPACE_SIDEBAR_ITEMS)
    items += _build_connector_settings_sidebar_items()
    items += _build_log_items()

    # Title must stay == SETTINGS_WORKSPACE_NAME — see create_or_update_workspace_sidebar().
    common_fields = {
        "title":             SETTINGS_WORKSPACE_NAME,
        "for_user":          "",
        "standard":          1,
        "app":               "alaiy_os",
        "module_onboarding": None,
    }

    if frappe.db.exists("Workspace Sidebar", SETTINGS_WORKSPACE_NAME):
        sidebar = frappe.get_doc("Workspace Sidebar", SETTINGS_WORKSPACE_NAME)
        for k, v in common_fields.items():
            sidebar.set(k, v)
        sidebar.set("items", [])
        for item in items:
            sidebar.append("items", item)
        sidebar.flags.ignore_links = True
        sidebar.save(ignore_permissions=True)
    else:
        sidebar = frappe.get_doc({
            "doctype": "Workspace Sidebar",
            **common_fields,
            "items":   items,
        })
        sidebar.flags.ignore_links = True
        sidebar.insert(ignore_permissions=True)


# ── Module Onboarding ─────────────────────────────────────────────────────────

def _create_or_update_onboarding_steps():
    """
    Create or update standalone Onboarding Step records.
    Returns a list of step names for referencing from Module Onboarding.
    """
    step_names = []
    for step_def in ONBOARDING_STEPS:
        step_name = step_def["name"]
        fields = {k: v for k, v in step_def.items() if k != "name"}
        if not frappe.db.exists("Onboarding Step", step_name):
            try:
                frappe.get_doc({
                    "doctype": "Onboarding Step",
                    "name":    step_name,
                    **fields,
                }).insert(ignore_permissions=True)
            except Exception:
                frappe.log_error(
                    title=f"Alaiy OS: could not create Onboarding Step {step_name!r}",
                    message=frappe.get_traceback(),
                )
        else:
            frappe.db.set_value("Onboarding Step", step_name, fields)
        step_names.append(step_name)
    return step_names


def create_or_update_onboarding():
    """
    Always create/update the Module Onboarding record and its Onboarding Steps.
    """
    step_names = _create_or_update_onboarding_steps()

    onboarding_doc = {
        "title":           "Get Started with Alaiy OS",
        "subtitle":        "Get your workspace ready in a few steps.",
        "success_message": "Great — your workspace is all set!",
        "documentation_url": "",
        "is_complete":     0,
        "module":          MODULE_NAME,
    }

    if not frappe.db.exists("Module Onboarding", ONBOARDING_NAME):
        doc = frappe.get_doc({
            "doctype": "Module Onboarding",
            "name":    ONBOARDING_NAME,
            **onboarding_doc,
            "steps":   [],
        })
        for name in step_names:
            doc.append("steps", {"step": name})
        # allow_roles is a child table; set it if the field exists on this Frappe version
        try:
            doc.set("allow_roles", [{"role": OS_MANAGER_ROLE}])
        except Exception:
            pass
        doc.flags.ignore_validate = True
        doc.insert(ignore_permissions=True)
    else:
        doc = frappe.get_doc("Module Onboarding", ONBOARDING_NAME)
        for k, v in onboarding_doc.items():
            doc.set(k, v)
        doc.set("steps", [])
        for name in step_names:
            doc.append("steps", {"step": name})
        try:
            doc.set("allow_roles", [{"role": OS_MANAGER_ROLE}])
        except Exception:
            pass
        doc.flags.ignore_validate = True
        doc.save(ignore_permissions=True)


# ── Dotted-path handler health check ─────────────────────────────────────────
#
# OS Agent Tool.handler and OS Connector Registry's test_method/sync_*_method
# fields are only validated once, at save time (OSAgentTool._validate_handler(),
# OSConnectorRegistry._validate_handlers()). If the app providing one is later
# uninstalled, or refactors the target function away, that's otherwise only
# discovered the next time something actually calls it — engine/factory.py's
# build_runnable() had no try/except around its frappe.get_attr() at all
# before this, and api/connectors.py's test/sync calls just report a generic
# {"success": False} either way. Re-check every registered path on every
# migrate instead, and record the result on the row itself so it's visible
# without waiting for a live failure.

def _resolve_handler(path):
    """(ok, detail) for a dotted path — ok only if it imports and is callable."""
    try:
        fn = frappe.get_attr(path)
    except Exception:
        return False, f"{path} could not be imported"
    if not callable(fn):
        return False, f"{path} is not callable"
    return True, ""


def _check_agent_tool_handlers():
    if not frappe.db.exists("DocType", "OS Agent Tool"):
        return
    for row in frappe.get_all("OS Agent Tool", fields=["name", "handler"]):
        if not row.handler:
            continue
        ok, detail = _resolve_handler(row.handler)
        frappe.db.set_value(
            "OS Agent Tool", row.name,
            {"handler_ok": 1 if ok else 0, "handler_health_detail": detail},
            update_modified=False,
        )


def _check_connector_registry_handlers():
    if not frappe.db.exists("DocType", "OS Connector Registry"):
        return
    fields = ["name"] + list(_HANDLER_FIELDS.keys())
    for row in frappe.get_all("OS Connector Registry", fields=fields):
        problems = []
        for fieldname, label in _HANDLER_FIELDS.items():
            path = row.get(fieldname)
            if not path:
                continue
            ok, detail = _resolve_handler(path)
            if not ok:
                problems.append(f"{label}: {detail}")
        frappe.db.set_value(
            "OS Connector Registry", row.name,
            {
                "handlers_ok": 0 if problems else 1,
                "handlers_health_detail": "; ".join(problems),
            },
            update_modified=False,
        )


def check_dotted_path_handlers():
    _check_agent_tool_handlers()
    _check_connector_registry_handlers()


# ── MCP tool roles ────────────────────────────────────────────────────────────

def ensure_assistant_roles():
    """Create the Alaiy Admin/Ops/Catalogue/Analyst roles the MCP tools gate on.

    Runs regardless of whether frappe_assistant_core is installed — the roles
    are ordinary desk roles and creating them early costs nothing, so a site
    that adds FAC later has a working permission model immediately.
    """
    _ensure_assistant_roles()
