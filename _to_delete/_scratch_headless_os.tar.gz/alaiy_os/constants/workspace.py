"""
Alaiy OS workspace definition — single source of truth for the Alaiy OS
workspace layout (shortcuts + link cards + sidebar).

Consumed by:
  - setup/install.py:create_or_update_workspace() and
    create_or_update_workspace_sidebar() (writes the DB records)
  - alaiy_os.api.workspace.sidebar_config_js() (derives the JS click-router's
    ALAIY_SIDEBAR_CONFIG from WORKSPACE_SIDEBAR_ITEMS on every request —
    there is no separate JS file to keep in sync; edit WORKSPACE_SIDEBAR_ITEMS
    below and both consumers pick it up automatically)
"""

WORKSPACE_NAME = "OS"
WORKSPACE_ROUTE = "os"  # URL slug: /desk/os

WORKSPACE_SHORTCUTS = [
    {"type": "Page", "link_to": "ask-alaiy",
        "label": "Ask Alaiy",   "color": "purple"},
    {"type": "DocType", "link_to": "Stock Entry",
        "label": "Dashboard",   "color": "blue"},
]

WORKSPACE_LINKS = [
    # ── CATALOG ────────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Catalog", "icon": "grid"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Item",                    "label": "Products"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Item Group",              "label": "Item Group"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Item Attribute",          "label": "Item Attribute"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Brand",                   "label": "Brand"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Item Price",              "label": "Item Price"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Price List",              "label": "Price List"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Pricing Rule",            "label": "Pricing Rule"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Manufacturer",            "label": "Manufacturer"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Batch",                   "label": "Batch"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Serial No",               "label": "Serial No"},

    # ── INVENTORY ──────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Inventory", "icon": "archive"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Stock Entry",             "label": "Stock Entry"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Stock Reconciliation",    "label": "Stock Reconciliation"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Warehouse",               "label": "Warehouse"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Warehouse Type",          "label": "Warehouse Type"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "UOM",                     "label": "Unit of Measure"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Stock Entry Type",        "label": "Stock Entry Type"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Putaway Rule",            "label": "Putaway Rule"},

    # ── QUALITY ────────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Quality", "icon": "shield-check"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Quality Inspection Template",        "label": "Inspection Templates"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Quality Inspection Parameter",       "label": "Parameters"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Quality Inspection Parameter Group", "label": "Parameter Groups"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Item Quality Inspection Parameter",  "label": "Item QC Parameters"},

    # ── SALES ──────────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Sales", "icon": "trending-up"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Sales Order",             "label": "Sales Order"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Sales Invoice",           "label": "Sales Invoice"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Product Bundle",          "label": "Product Bundle"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Sales Person",            "label": "Sales Person"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Sales Partner",           "label": "Sales Partner"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "POS Profile",             "label": "POS Profile"},

    # ── PROCUREMENT ────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Procurement", "icon": "package-search"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Purchase Order",          "label": "Purchase Order"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Purchase Invoice",        "label": "Purchase Invoice"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Purchase Receipt",        "label": "Purchase Receipt"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Supplier",                "label": "Supplier"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Supplier Group",          "label": "Supplier Group"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Supplier Scorecard",      "label": "Supplier Scorecard"},

    # ── CUSTOMERS ──────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Customers", "icon": "users"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Customer",                "label": "Customer"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Customer Group",          "label": "Customer Group"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Address",                 "label": "Address"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "UTM Source",              "label": "UTM Source"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Contact",                 "label": "Contacts"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Coupon Code",             "label": "Coupon Code"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Loyalty Program",         "label": "Loyalty Program"},

    # ── SHIPPING ───────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Shipping", "icon": "truck"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Delivery Note",           "label": "Delivery Note"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Shipping Rule",           "label": "Shipping Rule"},

    # ── FINANCE ────────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Finance", "icon": "landmark"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Payment Ledger Entry",    "label": "Payment Ledger"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Payment Reconciliation",  "label": "Payment Reconciliation"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Payment Term",            "label": "Payment Term"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Bank Reconciliation Tool", "label": "Bank Reconciliation"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Tax Category",            "label": "Tax Category"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Tax Rule",                "label": "Tax Rule"},

    # ── ACCOUNTS ───────────────────────────────────────────────────────────────
    {"type": "Card Break", "label": "Accounts", "icon": "wallet"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Account",                 "label": "Account"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Cost Center",             "label": "Cost Center"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Finance Book",            "label": "Finance Book"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Fiscal Year",             "label": "Fiscal Year"},
    {"type": "Link", "link_type": "DocType",
        "link_to": "Currency Exchange",       "label": "Currency Exchange"},
]

# Sidebar items — the JS click-router's ALAIY_SIDEBAR_CONFIG is generated
# from this list (see alaiy_os.api.workspace.sidebar_config_js); nothing
# else needs updating here. icon names are Lucide/Frappe icon names.
WORKSPACE_SIDEBAR_ITEMS = [
    # ── Top standalone actions ─────────────────────────────────────────────────
    {"type": "Link", "link_type": "Page", "link_to": "ask-alaiy",
     "label": "Ask Alaiy",  "child": 0, "indent": 0, "icon": "sparkles"},
    {"type": "Link", "link_type": "Workspace", "link_to": WORKSPACE_NAME,
     "label": "Dashboard",  "child": 0, "indent": 0, "icon": "layout-dashboard"},

    # ── Catalog ────────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Catalog",
        "icon": "grid",             "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Item",
     "label": "Products",           "child": 1, "icon": "package"},
    {"type": "Link", "link_type": "DocType", "link_to": "Item Group",
     "label": "Item Group",         "child": 1, "icon": "boxes"},
    {"type": "Link", "link_type": "DocType", "link_to": "Item Attribute",
     "label": "Item Attribute",     "child": 1, "icon": "list-filter"},
    {"type": "Link", "link_type": "DocType", "link_to": "Brand",
     "label": "Brand",              "child": 1, "icon": "badge"},
    {"type": "Link", "link_type": "DocType", "link_to": "Item Price",
     "label": "Item Price",         "child": 1, "icon": "tag"},
    {"type": "Link", "link_type": "DocType", "link_to": "Price List",
     "label": "Price List",         "child": 1, "icon": "tags"},
    {"type": "Link", "link_type": "DocType", "link_to": "Pricing Rule",
     "label": "Pricing Rule",       "child": 1, "icon": "badge-percent"},
    {"type": "Link", "link_type": "DocType", "link_to": "Manufacturer",
     "label": "Manufacturer",       "child": 1, "icon": "building-2"},
    {"type": "Link", "link_type": "DocType", "link_to": "Batch",
     "label": "Batch",              "child": 1, "icon": "layers"},
    {"type": "Link", "link_type": "DocType", "link_to": "Serial No",
     "label": "Serial No",          "child": 1, "icon": "hash"},

    # ── Inventory ──────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Inventory",
        "icon": "archive",          "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Stock Entry",
     "label": "Stock Entry",              "child": 1, "icon": "package-plus"},
    {"type": "Link", "link_type": "DocType", "link_to": "Stock Reconciliation",
     "label": "Stock Reconciliation",     "child": 1, "icon": "clipboard-check"},
    {"type": "Link", "link_type": "DocType", "link_to": "Warehouse",
     "label": "Warehouse",                "child": 1, "icon": "warehouse"},
    {"type": "Link", "link_type": "DocType", "link_to": "Warehouse Type",
     "label": "Warehouse Type",           "child": 1, "icon": "factory"},
    {"type": "Link", "link_type": "DocType", "link_to": "UOM",
     "label": "Unit of Measure",          "child": 1, "icon": "ruler"},
    {"type": "Link", "link_type": "DocType", "link_to": "UOM Category",
     "label": "UOM Category",             "child": 1, "icon": "folder-tree"},
    {"type": "Link", "link_type": "DocType", "link_to": "Stock Entry Type",
     "label": "Stock Entry Type",         "child": 1, "icon": "list-checks"},
    {"type": "Link", "link_type": "DocType", "link_to": "Putaway Rule",
     "label": "Putaway Rule",             "child": 1, "icon": "arrow-down-to-line"},

    # ── Quality ────────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Quality",
        "icon": "shield-check",     "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Quality Inspection Template",
     "label": "Inspection Templates",     "child": 1, "icon": "file-check"},
    {"type": "Link", "link_type": "DocType", "link_to": "Quality Inspection Parameter",
     "label": "Parameters",               "child": 1, "icon": "list-checks"},
    {"type": "Link", "link_type": "DocType", "link_to": "Quality Inspection Parameter Group",
     "label": "Parameter Groups",         "child": 1, "icon": "folder-open"},
    {"type": "Link", "link_type": "DocType", "link_to": "Item Quality Inspection Parameter",
     "label": "Item QC Parameters",       "child": 1, "icon": "package-check"},

    # ── Sales ──────────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Sales",
        "icon": "trending-up",      "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Order",
     "label": "Sales Order",              "child": 1, "icon": "shopping-cart"},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Invoice",
     "label": "Sales Invoice",            "child": 1, "icon": "receipt"},
    {"type": "Link", "link_type": "DocType", "link_to": "Delivery Note",
     "label": "Delivery Note",            "child": 1, "icon": "package-open"},
    {"type": "Link", "link_type": "DocType", "link_to": "Product Bundle",
     "label": "Product Bundle",           "child": 1, "icon": "package-2"},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Partner Type",
     "label": "Sales Partner Type",       "child": 1, "icon": "handshake"},
    {"type": "Link", "link_type": "DocType", "link_to": "Industry Type",
     "label": "Industry Type",            "child": 1, "icon": "building"},
    {"type": "Link", "link_type": "DocType", "link_to": "Party Specific Item",
     "label": "Party Specific Item",      "child": 1, "icon": "user-round-check"},
    {"type": "Link", "link_type": "DocType", "link_to": "Competitor",
     "label": "Competitor",               "child": 1, "icon": "swords"},
    {"type": "Link", "link_type": "DocType", "link_to": "Market Segment",
     "label": "Market Segment",           "child": 1, "icon": "chart-pie"},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Stage",
     "label": "Sales Stage",              "child": 1, "icon": "git-branch"},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Person",
     "label": "Sales Person",             "child": 1, "icon": "user-round"},
    {"type": "Link", "link_type": "DocType", "link_to": "Sales Partner",
     "label": "Sales Partner",            "child": 1, "icon": "users-round"},
    {"type": "Link", "link_type": "DocType", "link_to": "POS Profile",
     "label": "POS Profile",              "child": 1, "icon": "credit-card"},

    # ── Procurement ────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Procurement",
        "icon": "package-search",   "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Purchase Order",
     "label": "Purchase Order",           "child": 1, "icon": "file-input"},
    {"type": "Link", "link_type": "DocType", "link_to": "Purchase Invoice",
     "label": "Purchase Invoice",         "child": 1, "icon": "file-text"},
    {"type": "Link", "link_type": "DocType", "link_to": "Purchase Receipt",
     "label": "Purchase Receipt",         "child": 1, "icon": "package-check"},
    {"type": "Link", "link_type": "DocType", "link_to": "Supplier",
     "label": "Supplier",                 "child": 1, "icon": "truck"},
    {"type": "Link", "link_type": "DocType", "link_to": "Supplier Group",
     "label": "Supplier Group",           "child": 1, "icon": "network"},
    {"type": "Link", "link_type": "DocType", "link_to": "Supplier Scorecard",
     "label": "Supplier Scorecard",       "child": 1, "icon": "star"},

    # ── Customers ──────────────────────────────────────────────────────────────
    # Link label "Customer" (singular) avoids ALAIY_SKIP_LABELS collision with
    # the "Customers" section header (plural).
    {"type": "Section Break", "label": "Customers",
        "icon": "users",            "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Customer",
     "label": "Customer",                 "child": 1, "icon": "user"},
    {"type": "Link", "link_type": "DocType", "link_to": "Customer Group",
     "label": "Customer Group",           "child": 1, "icon": "users-round"},
    {"type": "Link", "link_type": "DocType", "link_to": "Address",
     "label": "Address",                  "child": 1, "icon": "map-pinned"},
    {"type": "Link", "link_type": "DocType", "link_to": "UTM Source",
     "label": "UTM Source",               "child": 1, "icon": "mouse-pointer-click"},
    {"type": "Link", "link_type": "DocType", "link_to": "Contact",
     "label": "Contacts",                 "child": 1, "icon": "book-user"},
    {"type": "Link", "link_type": "DocType", "link_to": "Coupon Code",
     "label": "Coupon Code",              "child": 1, "icon": "ticket"},
    {"type": "Link", "link_type": "DocType", "link_to": "Promotional Scheme",
     "label": "Promotional Scheme",       "child": 1, "icon": "gift"},
    {"type": "Link", "link_type": "DocType", "link_to": "Loyalty Program",
     "label": "Loyalty Program",          "child": 1, "icon": "badge-dollar-sign"},
    {"type": "Link", "link_type": "DocType", "link_to": "Subscription Plan",
     "label": "Subscription Plan",        "child": 1, "icon": "calendar-clock"},
    {"type": "Link", "link_type": "DocType", "link_to": "Campaign",
     "label": "Campaign",                 "child": 1, "icon": "megaphone"},

    # ── Shipping ───────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Shipping",
        "icon": "truck",            "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Delivery Note",
     "label": "Delivery Note",            "child": 1, "icon": "package-open"},
    {"type": "Link", "link_type": "DocType", "link_to": "Shipping Rule",
     "label": "Shipping Rule",            "child": 1, "icon": "truck"},

    # ── Finance ────────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Finance",
        "icon": "landmark",         "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Payment Ledger Entry",
     "label": "Payment Ledger",           "child": 1, "icon": "book-open-text"},
    {"type": "Link", "link_type": "DocType", "link_to": "Payment Reconciliation",
     "label": "Payment Reconciliation",   "child": 1, "icon": "merge"},
    {"type": "Link", "link_type": "DocType", "link_to": "Payment Term",
     "label": "Payment Term",             "child": 1, "icon": "calendar-days"},
    {"type": "Link", "link_type": "DocType", "link_to": "Bank Reconciliation Tool",
     "label": "Bank Reconciliation",      "child": 1, "icon": "banknote"},
    {"type": "Link", "link_type": "DocType", "link_to": "Tax Category",
     "label": "Tax Category",             "child": 1, "icon": "badge"},
    {"type": "Link", "link_type": "DocType", "link_to": "Tax Rule",
     "label": "Tax Rule",                 "child": 1, "icon": "scale"},
    {"type": "Link", "link_type": "DocType", "link_to": "Tax Withholding Category",
     "label": "Tax Withholding Category", "child": 1, "icon": "file"},
    {"type": "Link", "link_type": "DocType", "link_to": "Tax Withholding Group",
     "label": "Tax Withholding Group",    "child": 1, "icon": "folder"},

    # ── Accounts ───────────────────────────────────────────────────────────────
    {"type": "Section Break", "label": "Accounts",
        "icon": "wallet",           "child": 0, "indent": 1},
    {"type": "Link", "link_type": "DocType", "link_to": "Account",
     "label": "Account",                  "child": 1, "icon": "landmark"},
    {"type": "Link", "link_type": "DocType", "link_to": "Cost Center",
     "label": "Cost Center",              "child": 1, "icon": "coins"},
    {"type": "Link", "link_type": "DocType", "link_to": "Finance Book",
     "label": "Finance Book",             "child": 1, "icon": "book"},
    {"type": "Link", "link_type": "DocType", "link_to": "Fiscal Year",
     "label": "Fiscal Year",              "child": 1, "icon": "calendar"},
    {"type": "Link", "link_type": "DocType", "link_to": "Currency Exchange",
     "label": "Currency Exchange",        "child": 1, "icon": "currency"},

    # Connector sections (one per installed connector) get appended after
    # this list by setup/install.py::create_or_update_workspace_sidebar();
    # "Settings" is appended after those (see WORKSPACE_SIDEBAR_SETTINGS_ITEM
    # below) so it stays pinned at the very bottom, below the connectors.
]

# Kept separate from WORKSPACE_SIDEBAR_ITEMS so it can be appended AFTER the
# dynamically-built connector sections instead of before them.
WORKSPACE_SIDEBAR_SETTINGS_ITEM = {
    "type": "Link", "link_type": "Workspace", "link_to": "OS Settings",
    "label": "Settings", "child": 0, "indent": 0, "icon": "settings",
}
