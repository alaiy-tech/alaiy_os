frappe.pages['ai-credits'].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'AI Credits',
		single_column: true,
	});

	let cur = 'USD';

	function money(amount, currency) {
		try {
			return new Intl.NumberFormat(undefined, {
				style: 'currency',
				currency: currency || 'USD',
			}).format(Number(amount || 0));
		} catch (e) {
			return (currency || '') + ' ' + Number(amount || 0).toFixed(2);
		}
	}

	const $body = $(`
		<div class="ai-credits" style="padding:20px;max-width:520px;">
			<div style="padding:24px;border:1px solid var(--border-color);border-radius:12px;margin-bottom:20px;">
				<div style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.5px;">Balance remaining</div>
				<div class="balance-amount" style="font-size:34px;font-weight:600;margin-top:6px;">…</div>
			</div>
			<button class="btn btn-primary btn-topup">Top up credits</button>
			<div class="topup-status" style="margin-top:16px;color:var(--text-muted);"></div>
		</div>
	`).appendTo(page.body);

	const $amount = $body.find('.balance-amount');
	const $status = $body.find('.topup-status');

	function refresh() {
		$amount.text('…');
		frappe.xcall('alaiy_os_ai_client.billing.get_balance')
			.then((b) => {
				cur = b.currency || 'USD';
				$amount.text(money(b.balance, cur));
			})
			.catch(() => $amount.text('unavailable'));
	}

	function startTopup(amount) {
		$status.text('Creating order…');
		frappe.xcall('alaiy_os_ai_client.billing.create_topup_order', { amount })
			.then((order) => {
				if (order.key_id === 'rzp_test_mock') {
					frappe.confirm(
						`Mock payment of ${money(order.amount, order.currency)} for order <b>${order.order_id}</b>. Proceed?`,
						() =>
							frappe
								.xcall('alaiy_os_ai_client.billing.confirm_topup', { order_id: order.order_id })
								.then(done)
								.catch(fail)
					);
				} else {
					openRazorpay(order);
				}
			})
			.catch(fail);
	}

	function loadRazorpay() {
		return new Promise((resolve, reject) => {
			if (window.Razorpay) return resolve();
			const s = document.createElement('script');
			s.src = 'https://checkout.razorpay.com/v1/checkout.js';
			s.onload = () => resolve();
			s.onerror = () => reject(new Error('load failed'));
			document.body.appendChild(s);
		});
	}

	function openRazorpay(order) {
		loadRazorpay()
			.then(() => {
				new Razorpay({
					key: order.key_id,
					order_id: order.order_id,
					amount: Math.round(order.amount * 100),
					currency: order.currency,
					name: 'Alaiy OS',
					description: 'Top up AI credits',
					handler: (resp) => {
						$status.text('Verifying payment…');
						frappe
							.xcall('alaiy_os_ai_client.billing.verify_topup', {
								razorpay_order_id: resp.razorpay_order_id,
								razorpay_payment_id: resp.razorpay_payment_id,
								razorpay_signature: resp.razorpay_signature,
							})
							.then(done)
							.catch(fail);
					},
				}).open();
			})
			.catch(fail);
	}

	function done(b) {
		cur = b.currency || cur;
		$status.html(
			`<span style="color:var(--green-600)">Payment ${b.status}. Balance: ${money(b.balance, cur)}.</span>`
		);
		refresh();
	}

	function fail() {
		$status.text('Top-up failed.');
	}

	$body.find('.btn-topup').on('click', () => {
		frappe.prompt(
			[{ fieldname: 'amount', label: __('Amount ({0})', [cur]), fieldtype: 'Float', reqd: 1, default: 10 }],
			({ amount }) => startTopup(amount),
			'Top up credits',
			'Continue'
		);
	});

	refresh();
};
