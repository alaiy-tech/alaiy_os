"""Provision this bench's gateway config from the billing service.

The bench cannot mint its own LiteLLM key — that needs the master key, which by
design never touches the bench. On install we ask the billing service (the
master-key holder) to create a per-site virtual key, then write the returned
gateway URL + key into site_config. Idempotent: skips if a key is already set,
and the billing service itself is idempotent per site.

Both values needed to reach billing ship with the app, so `bench install-app`
alone fully configures a managed bench — no site_config editing, no manual step.
Either can still be overridden in site_config / common_site_config when a bench
must point somewhere else (local billing during development, a staging host):

  billing_url                where the billing service lives. Not a secret.
  billing_bootstrap_token    shared credential authorizing "provision my own
                             bench" — nothing else. Overridable per bench.

SECURITY NOTE: shipping the bootstrap token in the app puts it on every managed
bench's filesystem, and it authorizes provisioning ANY site name — so a customer
who reads it could mint or churn keys for another site. It is deliberately much
weaker than the LiteLLM master key (which never leaves billing), but it is not
nothing. The fix is for billing to verify domain ownership instead of accepting
a shared secret: bench posts its site, billing calls back to that host with a
nonce and expects it echoed. Then no secret ships at all.
"""

import frappe

# Managed-fleet defaults. These make install-and-go work; override in site config
# to point a bench at a different billing service.
DEFAULT_BILLING_URL = "http://13.234.141.70:8080"
DEFAULT_BOOTSTRAP_TOKEN = "alaiy-bootstrap-H3h_5d3P7MZyL00Djql-PKYu5ehQZhR-"


def after_install():
    """install hook — never abort the install if provisioning can't complete."""
    if frappe.conf.get("ai_gateway_key"):
        print("[alaiy_os_ai_client] ai_gateway_key already set — skipping provisioning.")
        return
    try:
        result = _provision()
        print(f"[alaiy_os_ai_client] provisioning: {result}")
    except Exception as e:
        frappe.log_error(title="AI gateway provisioning failed")
        print(
            f"[alaiy_os_ai_client] provisioning FAILED: {e!r}\n"
            "  Fix billing_url / billing_bootstrap_token and run:\n"
            "  bench --site <site> execute alaiy_os_ai_client.setup.provision.provision_now"
        )


def after_migrate():
    """Re-sync gateway config on every migrate, so a managed fleet self-heals.

    Why this exists: the gateway URL a bench stores is a snapshot taken at
    install time. If billing later hands out a different address (moved host,
    localhost -> public URL, IP change), every already-installed bench keeps
    calling the old one and simply stops working. Without this, fixing that
    means running provision_now(force=True) by hand on every site.

    Safe to repeat: billing is idempotent per site, so this reuses the existing
    virtual key — budget and accumulated spend are untouched. Only the gateway
    URL and the bench token are refreshed (billing issues a fresh bench token on
    every provision call, and we store it, so the two never drift apart).

    Never aborts a migrate: a billing outage must not block a deploy.
    """
    if not frappe.conf.get("ai_gateway_key"):
        return  # never provisioned — after_install owns that path
    try:
        before = frappe.conf.get("ai_gateway_url")
        result = _provision(force=True)
        after = frappe.conf.get("ai_gateway_url")
        if before != after:
            print(f"[alaiy_os_ai_client] gateway URL updated: {before} -> {after}")
        else:
            print(f"[alaiy_os_ai_client] gateway config in sync ({after})")
        return result
    except Exception as e:
        frappe.log_error(title="AI gateway re-sync failed")
        print(
            f"[alaiy_os_ai_client] gateway re-sync FAILED (continuing): {e!r}\n"
            "  The bench keeps its existing config; retry with:\n"
            "  bench --site <site> execute alaiy_os_ai_client.setup.provision.provision_now "
            "--kwargs \"{'force': True}\""
        )


@frappe.whitelist()
def provision_now(force: bool = False):
    """Manual (re)provision trigger — e.g. if install-time provisioning failed."""
    frappe.only_for("System Manager")
    return _provision(force=frappe.parse_json(force) if isinstance(force, str) else force)


def _provision(force: bool = False):
    if frappe.conf.get("ai_gateway_key") and not force:
        return {"provisioned": False, "reason": "already provisioned"}

    billing_url = frappe.conf.get("billing_url") or DEFAULT_BILLING_URL
    token = frappe.conf.get("billing_bootstrap_token") or DEFAULT_BOOTSTRAP_TOKEN
    if not token:
        raise RuntimeError(
            "no billing_bootstrap_token in site config and no shipped default. "
            f"(billing_url resolved to {billing_url!r}.)"
        )

    import requests
    from frappe.installer import update_site_config

    resp = requests.post(
        f"{billing_url.rstrip('/')}/provision",
        headers={"Authorization": f"Bearer {token}"},
        json={"site": frappe.local.site},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()

    update_site_config("ai_gateway_url", data["gateway_url"])
    update_site_config("ai_gateway_key", data["key"])
    # Per-bench token for ongoing bench-facing calls (balance, top-up). The
    # shared bootstrap token is only used for this provisioning call.
    update_site_config("billing_bench_token", data["bench_token"])
    return {"provisioned": True, "reused": data.get("reused")}
