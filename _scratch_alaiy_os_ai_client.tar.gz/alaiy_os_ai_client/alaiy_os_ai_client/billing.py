"""Bench-facing proxy to the billing service.

The bench holds no billing logic and no money authority — these whitelisted
methods just forward the desk UI's requests to the billing service (using the
per-bench bootstrap token) and relay the read-only result back. All markup /
ledger / budget logic lives off-bench in the billing service.
"""

import frappe

from alaiy_os_ai_client.setup.provision import DEFAULT_BILLING_URL


def _billing():
    """URL + auth headers for ongoing bench-facing calls.

    Uses the per-bench token (issued at provisioning, bound server-side to this
    site). The billing service derives the site from this token, so we never
    send the site in the request — it can only ever act on our own bench.
    """
    url = frappe.conf.get("billing_url") or DEFAULT_BILLING_URL
    token = frappe.conf.get("billing_bench_token")
    if not token:
        frappe.throw("Billing is not configured on this site (not provisioned).")
    return url.rstrip("/"), {"Authorization": f"Bearer {token}"}


def _display_balance(balance_usd):
    """Billing is USD-internal and credits are always priced in USD, so this is
    a straight pass-through — no ERP currency lookup, no exchange rate."""
    return {"balance": round(float(balance_usd or 0), 2), "currency": "USD"}


@frappe.whitelist()
def get_balance():
    """Read-only balance mirror, in USD."""
    import requests

    url, headers = _billing()
    r = requests.get(f"{url}/balance", headers=headers, timeout=20)
    r.raise_for_status()
    return _display_balance(r.json().get("balance_usd"))


@frappe.whitelist()
def create_topup_order(amount):
    """Create a Razorpay order for `amount` USD."""
    frappe.only_for("System Manager")
    import requests

    amount = round(float(amount), 2)

    url, headers = _billing()
    r = requests.post(
        f"{url}/topup/order",
        json={"amount": amount, "currency": "USD", "amount_usd": amount},
        headers=headers,
        timeout=20,
    )
    r.raise_for_status()
    return r.json()


@frappe.whitelist()
def confirm_topup(order_id):
    """Confirm a MOCK payment (only works when Razorpay is disabled in billing).
    Real payments are credited via verify_topup / the Razorpay webhook."""
    frappe.only_for("System Manager")
    import requests

    url, headers = _billing()
    r = requests.post(
        f"{url}/topup/confirm", json={"order_id": order_id}, headers=headers, timeout=20
    )
    r.raise_for_status()
    data = r.json()
    return {"status": data.get("status"), **_display_balance(data.get("balance_usd"))}


@frappe.whitelist()
def verify_topup(razorpay_order_id, razorpay_payment_id, razorpay_signature):
    """Relay a Razorpay Checkout success callback to billing for signature
    verification + crediting. The bench never verifies signatures itself."""
    frappe.only_for("System Manager")
    import requests

    url, headers = _billing()
    r = requests.post(
        f"{url}/topup/verify",
        json={
            "razorpay_order_id": razorpay_order_id,
            "razorpay_payment_id": razorpay_payment_id,
            "razorpay_signature": razorpay_signature,
        },
        headers=headers,
        timeout=20,
    )
    r.raise_for_status()
    data = r.json()
    return {"status": data.get("status"), **_display_balance(data.get("balance_usd"))}
