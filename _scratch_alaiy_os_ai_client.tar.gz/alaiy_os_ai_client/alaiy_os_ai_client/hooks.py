app_name = "alaiy_os_ai_client"
app_title = "Alaiy OS AI Client"
app_publisher = "Alaiy"
app_description = "Managed-bench AI client: routes Alaiy OS agent calls through our LiteLLM proxy."
app_version = "0.0.1"
required_apps = ["alaiy_os"]

# --- The one thing this app exists to do -------------------------------------
# Override the `ai_client` seam defined by alaiy_os core. Frappe resolves scalar
# hooks by install order, so as long as this app is installed AFTER alaiy_os in
# apps.txt, its client wins and agent calls route through our LiteLLM proxy
# instead of the customer's own key (BYOK).
ai_client = "alaiy_os_ai_client.ai.client.get_ai_client"

# On install, auto-provision this bench's gateway key from the billing service
# (the master-key holder) and write it into site_config. Idempotent.
after_install = "alaiy_os_ai_client.setup.provision.after_install"

# On migrate, re-sync the stored gateway URL/token. The address is a snapshot
# taken at install time, so without this a bench keeps calling a stale gateway
# forever if billing is ever moved. Reuses the existing key; never blocks a
# migrate if billing is unreachable.
after_migrate = "alaiy_os_ai_client.setup.provision.after_migrate"

# Show the AI credit balance + top-up button in the OS Agent Registry list.
doctype_list_js = {"OS Agent Registry": "public/js/os_agent_registry_list.js"}
