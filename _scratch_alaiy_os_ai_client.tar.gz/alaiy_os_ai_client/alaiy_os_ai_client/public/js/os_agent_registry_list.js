// Adds a credits/top-up control to the OS Agent Registry list header. MERGES
// into core's frappe.listview_settings (never reassigns) so the existing card
// rendering is untouched. Balance + payments are always in USD, matching the
// billing service's internal unit.
(function () {
	const KEY = 'OS Agent Registry';
	const settings = frappe.listview_settings[KEY] || (frappe.listview_settings[KEY] = {});
	const prevOnload = settings.onload;

	settings.onload = function (listview) {
		if (prevOnload) prevOnload.call(this, listview);
		mountCredits(listview);
	};

	function money(amount, currency) {
		try {
			return new Intl.NumberFormat(undefined, {
				style: 'currency',
				currency: currency || 'USD',
			}).format(Number(amount || 0));
		} catch (e) {
			return (currency || '') + ' ' + Number(amount || 0).toFixed(2);
		}
	}

	function mountCredits(listview) {
		let cur = 'USD';
		const $btn = listview.page.add_inner_button(__('…'), () => openCredits());

		function setLabel(bal) {
			$btn.text(bal == null ? __('Credits') : __('{0} left', [money(bal, cur)]));
		}

		function refreshBalance() {
			return frappe
				.xcall('alaiy_os_ai_client.billing.get_balance')
				.then((b) => {
					cur = b.currency || 'USD';
					setLabel(b.balance);
					return b;
				})
				.catch(() => setLabel(null));
		}

		function openCredits() {
			const d = new frappe.ui.Dialog({ title: ' ' });
			d.$wrapper.find('.modal-header').css('border-bottom', 'none');
			d.$body.html(`
				<div style="text-align:center;padding:0 8px 20px;">
					<div style="font-size:24px;font-weight:700;margin-bottom:24px;">${__('AI Credits')}</div>
					<div class="ac-bal" style="font-size:44px;font-weight:700;line-height:1;">…</div>
					<div style="color:var(--text-muted);font-size:12px;margin-top:10px;text-transform:uppercase;letter-spacing:.6px;">${__('balance remaining')}</div>
					<button class="btn btn-primary ac-topup" style="width:100%;margin-top:26px;">${__('Top up credits')}</button>
				</div>
			`);
			d.$body.find('.ac-topup').on('click', () => {
				d.hide();
				openTopup();
			});
			d.show();
			frappe
				.xcall('alaiy_os_ai_client.billing.get_balance')
				.then((b) => {
					cur = b.currency || 'USD';
					d.$body.find('.ac-bal').text(money(b.balance, cur));
					setLabel(b.balance);
				})
				.catch(() => d.$body.find('.ac-bal').text(__('unavailable')));
		}

		function openTopup() {
			const chips = [5, 10, 25, 50];
			const d = new frappe.ui.Dialog({ title: ' ' });
			d.$wrapper.find('.modal-header').css('border-bottom', 'none');
			d.$body.html(`
				<div style="padding:0 4px 12px;">
					<div style="font-size:24px;font-weight:700;text-align:center;margin-bottom:24px;">${__('Top up credits')}</div>
					<div style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.6px;margin-bottom:10px;">${__('Choose an amount')}</div>
					<div class="ac-chips" style="display:flex;gap:8px;margin-bottom:18px;">
						${chips
							.map(
								(a) =>
									`<button type="button" class="btn btn-default btn-sm ac-chip" data-amt="${a}" style="flex:1;">${money(a, cur)}</button>`
							)
							.join('')}
					</div>
					<div style="font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.6px;margin-bottom:6px;">${__('Or enter an amount ({0})', [cur])}</div>
					<input type="number" class="form-control ac-amount" min="1" step="1" value="10" />
					<button class="btn btn-primary ac-pay" style="width:100%;margin-top:22px;">${__('Continue')}</button>
				</div>
			`);

			const $amt = d.$body.find('.ac-amount');
			const $pay = d.$body.find('.ac-pay');
			const $chips = d.$body.find('.ac-chip');

			function markActive(val) {
				$chips.each(function () {
					const on = Number($(this).data('amt')) === Number(val);
					$(this).toggleClass('btn-primary', on).toggleClass('btn-default', !on);
				});
			}
			function syncPay() {
				const v = Number($amt.val());
				$pay.text(v > 0 ? __('Pay {0}', [money(v, cur)]) : __('Continue'));
				$pay.prop('disabled', !(v > 0));
			}

			$chips.on('click', function () {
				$amt.val($(this).data('amt'));
				markActive($amt.val());
				syncPay();
			});
			$amt.on('input', function () {
				markActive($amt.val());
				syncPay();
			});
			$pay.on('click', () => {
				const v = Number($amt.val());
				if (!(v > 0)) return;
				d.hide();
				createOrder(v);
			});

			markActive(10);
			syncPay();
			d.show();
			setTimeout(() => $amt.trigger('focus'), 200);
		}

		function createOrder(amount) {
			frappe
				.xcall('alaiy_os_ai_client.billing.create_topup_order', { amount })
				.then((order) => {
					if (order.key_id === 'rzp_test_mock') {
						frappe.confirm(
							__('Mock payment of {0} for order {1}. Proceed?', [
								money(order.amount, order.currency),
								order.order_id,
							]),
							() =>
								frappe
									.xcall('alaiy_os_ai_client.billing.confirm_topup', { order_id: order.order_id })
									.then(done)
									.catch(fail)
						);
					} else {
						openRazorpay(order);
					}
				})
				.catch(fail);
		}

		function loadRazorpay() {
			return new Promise((resolve, reject) => {
				if (window.Razorpay) return resolve();
				const s = document.createElement('script');
				s.src = 'https://checkout.razorpay.com/v1/checkout.js';
				s.onload = () => resolve();
				s.onerror = () => reject(new Error('load failed'));
				document.body.appendChild(s);
			});
		}

		function openRazorpay(order) {
			loadRazorpay()
				.then(() => {
					new Razorpay({
						key: order.key_id, // public key id, safe on the client
						order_id: order.order_id,
						amount: Math.round(order.amount * 100),
						currency: order.currency,
						name: 'Alaiy OS',
						description: 'Top up AI credits',
						handler: (resp) => {
							frappe
								.xcall('alaiy_os_ai_client.billing.verify_topup', {
									razorpay_order_id: resp.razorpay_order_id,
									razorpay_payment_id: resp.razorpay_payment_id,
									razorpay_signature: resp.razorpay_signature,
								})
								.then(done)
								.catch(fail);
						},
					}).open();
				})
				.catch(fail);
		}

		function done(b) {
			cur = b.currency || cur;
			frappe.show_alert({
				message: __('Payment {0}. Balance: {1}', [b.status, money(b.balance, cur)]),
				indicator: 'green',
			});
			setLabel(b.balance);
		}

		function fail() {
			frappe.show_alert({ message: __('Top-up failed.'), indicator: 'red' });
		}

		refreshBalance();
	}
})();
