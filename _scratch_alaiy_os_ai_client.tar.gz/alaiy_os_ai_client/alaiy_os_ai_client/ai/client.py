"""Managed AI client.

Implements the client contract that alaiy_os core's `ai_client` seam expects:

    complete(model, system, messages, tools=None) -> dict

returning exactly the shape core's executor consumes:

    {"content": [<block dict>, ...],
     "stop_reason": str,
     "usage": {"input_tokens": int, "output_tokens": int}}

plus the seam's two image capabilities:

    generate_image(prompt, reference_data_uri=None)
        -> {"b64": str, "media_type": str, "usage": dict}
    translate_image(image_url) -> {"translated_url": str}

For text, the only difference from core's default BYOK client is *where* the
request goes: we point the same Anthropic SDK at our LiteLLM proxy using a
per-site virtual key. LiteLLM speaks the Anthropic `/v1/messages` wire format, so
the message/tool/vision shapes and the return shape are identical to BYOK — no
change is needed anywhere in the executor or in agent code.

The image methods do not go through LiteLLM. They go to the billing service,
which holds the provider credentials and meters each call against the same
per-site budget — see its /image/generate and /image/translate endpoints.

The reason is translation: alphashop is not an LLM — no model id, its own JWT
auth and response contract — so no gateway can front it, whatever the model
catalogue carries. Billing has to serve that either way, and generation sits
beside it so both share one credential holder and one metering path.

That split is invisible to callers: both paths are reached through the one seam,
and both draw down the one balance. If image generation is later moved onto the
gateway, only this file changes.

Config is injected per-bench at provisioning time via site_config.json:

    {
      "ai_gateway_url": "https://litellm.example.com",   # LiteLLM root
      "ai_gateway_key": "sk-litellm-vk-cust_abc123...",  # per-site virtual key
      "billing_bench_token": "..."                        # image calls + balance
    }
"""

import frappe

from alaiy_os.engine.ai_client import Unsupported

DEFAULT_MAX_TOKENS = 16384


def max_tokens():
	"""The per-reply output cap, overridable per bench via site_config.json.

	Read at call time rather than import time: frappe.conf needs a site context,
	which does not exist when this module is first imported.

	    {"ai_max_tokens": 32000}

	Raising it costs nothing by itself — it is a ceiling, not an allocation, and
	only a reply that actually runs long spends the extra tokens.
	"""
	return int(frappe.conf.get("ai_max_tokens") or DEFAULT_MAX_TOKENS)


class InsufficientCredit(RuntimeError):
	"""The site is out of AI credit.

	Distinct from a provider failure: retrying will not help, and a caller
	rendering a batch should stop rather than collect the same 402 per image.
	"""

# Image calls are slow — a generated shot is about a minute, and the billing
# service retries a translation up to three times with backoff before giving up.
IMAGE_GENERATE_TIMEOUT = 240
IMAGE_TRANSLATE_TIMEOUT = 180


def get_ai_client():
	"""Factory registered on the `ai_client` hook."""
	return GatewayClient()


class GatewayClient:
	def __init__(self):
		# Captured now, on whatever thread built this client, because the image
		# methods may then be called from worker threads where frappe.conf is not
		# readable — see the seam contract in alaiy_os/engine/ai_client.py.
		from alaiy_os_ai_client.setup.provision import DEFAULT_BILLING_URL

		self._billing_url = (
			frappe.conf.get("billing_url") or DEFAULT_BILLING_URL
		).rstrip("/")
		self._bench_token = frappe.conf.get("billing_bench_token")

	def image_support(self):
		"""What this client can do, without making a call.

		Both capabilities ride on the same bench token, so they stand or fall
		together: a provisioned bench has both, an unprovisioned one has neither.
		Whether the billing service itself has each provider key configured is not
		visible from here — that surfaces as a 502 on the call.
		"""
		provisioned = bool(self._bench_token)
		return {"generate": provisioned, "translate": provisioned}

	def _client(self):
		import anthropic

		base_url = frappe.conf.get("ai_gateway_url")
		api_key = frappe.conf.get("ai_gateway_key")
		if not base_url or not api_key:
			frappe.throw(
				"Managed AI is not configured on this site. Set ai_gateway_url and "
				"ai_gateway_key in site_config.json."
			)
		# The Anthropic SDK appends /v1/messages to base_url; LiteLLM serves that
		# route and enforces this virtual key's budget on the request path.
		return anthropic.Anthropic(base_url=base_url, api_key=api_key)

	def complete(self, model, system, messages, tools=None):
		import anthropic

		client = self._client()
		kwargs = {
			"model": model,
			"max_tokens": max_tokens(),
			"system": system,
			"messages": messages,
			# Attribution for per-customer (and later per-agent) spend breakdown.
			# NOTE: the exact mechanism LiteLLM reads tags from on the Anthropic
			# route must be confirmed against our LiteLLM config before relying on
			# it for billing — see _tags(). Sending it is harmless if ignored.
			"extra_headers": {"x-litellm-tags": ",".join(self._tags())},
		}
		if tools:
			kwargs["tools"] = tools

		try:
			response = client.messages.create(**kwargs)
		except anthropic.APIStatusError as e:
			if _is_budget_exceeded(e):
				frappe.throw(
					"AI credits exhausted. Please top up to continue.",
					title="Insufficient balance",
				)
			raise

		if response.stop_reason == "max_tokens":
			# A reply cut off at the cap is not an answer, and core's executor does
			# not check for it: it treats any stop_reason that is not "tool_use" as a
			# finished turn. The truncation then surfaces much later wearing a
			# disguise — a cut-off final reply as an opaque "Unterminated string"
			# JSON parse error, a cut-off tool call as malformed tool arguments —
			# and for a JSON agent it also burns the corrective retry re-requesting
			# the same oversized document under the same cap. Saying it here costs
			# the truncated turn its place in the stored transcript, which is a good
			# trade for an error that names its own cause.
			frappe.throw(
				f"The model's reply was cut off at the {max_tokens()}-token output "
				"limit. Raise it with `ai_max_tokens` in site_config.json, or reduce "
				"what the agent has to emit."
			)

		return {
			"content": [block.model_dump() for block in response.content],
			"stop_reason": response.stop_reason,
			"usage": {
				"input_tokens": response.usage.input_tokens,
				"output_tokens": response.usage.output_tokens,
			},
		}

	def generate_image(self, prompt, reference_data_uri=None):
		"""One image, produced by the billing service on our OpenRouter key."""
		return self._image(
			"/image/generate",
			{"prompt": prompt, "reference_data_uri": reference_data_uri},
			IMAGE_GENERATE_TIMEOUT,
		)

	def translate_image(self, image_url):
		"""One photo's printed text translated, via the billing service.

		`image_url` must be publicly reachable: the provider fetches it itself and
		this never sends bytes. The URL that comes back is the provider's and may
		expire, so the caller re-hosts it.
		"""
		return self._image(
			"/image/translate", {"image_url": image_url}, IMAGE_TRANSLATE_TIMEOUT
		)

	def _image(self, path, payload, timeout):
		"""POST to a billing image endpoint and unwrap the result.

		Thread-safe: reads only state captured in __init__, and raises plain
		exceptions rather than calling frappe.throw, which needs a request context
		the worker threads calling this do not have.

		Out of credit is `InsufficientCredit` rather than a generic failure so a
		caller can stop the whole batch instead of burning through every remaining
		image to collect the same 402 each time.
		"""
		import requests

		if not self._bench_token:
			raise Unsupported(
				"Managed image services are not configured on this site (not "
				"provisioned). Run alaiy_os_ai_client.setup.provision.provision_now."
			)

		resp = requests.post(
			f"{self._billing_url}{path}",
			headers={"Authorization": f"Bearer {self._bench_token}"},
			json=payload,
			timeout=timeout,
		)
		if resp.status_code == 402:
			raise InsufficientCredit("AI credits exhausted. Please top up to continue.")
		if resp.status_code != 200:
			raise RuntimeError(f"{path} failed ({resp.status_code}): {resp.text[:500]}")
		return resp.json()

	def _tags(self):
		"""Attribution tags for this request.

		Only `site` is reliable here: the seam contract does not pass the agent
		or run identity. Per-agent tagging is a follow-up that depends on core
		exposing run context to the client.
		"""
		return [f"site:{frappe.local.site}"]


def _is_budget_exceeded(err):
	"""Whether an Anthropic-SDK error is LiteLLM's budget/spend-limit response.

	Do NOT key on status code alone: LiteLLM has returned budget errors as both
	400 and 429 across versions. Match the message so an upgrade can't silently
	turn this into a raw stack trace surfacing to the agent.
	"""
	if getattr(err, "status_code", None) not in (400, 429):
		return False
	text = str(getattr(err, "message", "") or err).lower()
	return "budget" in text or "exceeded" in text
