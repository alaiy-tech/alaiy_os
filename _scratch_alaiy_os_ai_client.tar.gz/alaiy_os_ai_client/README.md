# Alaiy OS AI Client

Private, managed-bench Frappe app. Installed **only** on benches we operate.

It overrides the `ai_client` seam in `alaiy_os` core so that agent LLM calls
route through our **LiteLLM proxy** (using a per-site virtual key) instead of a
customer-supplied Anthropic key (BYOK). The Anthropic wire format is preserved
end-to-end — LiteLLM serves the `/v1/messages` route — so nothing in the core
executor or in agent code changes.

## What it does

- Registers `ai_client` → `alaiy_os_ai_client.ai.client.get_ai_client` (scalar
  hook; wins because this app installs **after** `alaiy_os`).
- Points the Anthropic SDK at `ai_gateway_url` with the per-site
  `ai_gateway_key`.
- Translates LiteLLM budget-exceeded errors into a clean "top up" message.
- Tags requests for per-customer spend attribution.

It holds **no** billing logic, no ledger, no LiteLLM admin key — the virtual key
is data-plane only.

## Configuration (`site_config.json`, injected at provisioning)

```json
{
  "ai_gateway_url": "https://litellm.example.com",
  "ai_gateway_key": "sk-litellm-vk-cust_abc123..."
}
```

## Requirements

- `alaiy_os` installed first (this app must come after it in `apps.txt`).
- Core must delegate through the `ai_client` hook. Until that core seam lands,
  this app is inert.
